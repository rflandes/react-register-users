# Section 9: Profundizando Hooks y React
Source code: "react-ts-hooks-app-fin-seccion-09.zip"

* useState
* useRef
* useEffect
* Custom Hooks como:
    * useCounter
    * usePokemon
    * useTrafficLight
* Conectar múltiples custom hooks entre sí

```bash
npm create vite
```
Project name> 04-hooks-app
Select a framework> React
Select a variant> TypeScript + SWC

## 117. TailwindCSS y Estilos

https://tailwindcss.com/


```bash
npm install tailwindcss @tailwindcss/vite
```

vite.config.ts
```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
  ],
})
```

src\index.css
```css
@import "tailwindcss";
```

## 118. useState - Estado que se re-dibuja
Pasar una funcion (ej. setCount(prevCount => prevCount + 1)) es la forma recomendada para actualizar el estado cuando el nuevo valor se basa en el anterior. 
Esto asegura que siempre se esté trabajando con el valor más reciente, evitando problemas en actualizaciones rápidas o por lotes.

src\main.tsx
src\01-useState\TrafficLight.tsx
```js
    const [light, setLight] = useState('red');
```

change 
```js
    <div className="w-32 h-32 bg-red-500 rounded-full"></div>
```

for 
```js
    <div className={`w-32 h-32 ${light === 'red' ? colors[light] : 'bg-gray-500'} rounded-full`}></div>
``` 

## 119. Tipado estricto en useState

```js
type TrafficLightColor = 'red' | 'yellow' | 'green';
    
const [light, setLight] = useState<TrafficLightColor>('red');
```

## 120. useEffect - Disparar efectos secundarios
efectos secundarios - que se espera cuando el estado de un objeto cambia

src\02-useEffect\TrafficLightWithEffect.tsx

```js
    useEffect(() => {
        if (countDown === 0) return;
        console.log({ countDown });

        const intervalId = setInterval(() => {
            console.log('setInterval llamado')
            setCountDown((prev) => prev - 1);
        }, 1000);

        return () => {
            console.log('Clean up interval');
            clearInterval(intervalId);
        }
    }, [countDown]);
```

## 121. Recomendaciones del useEffect

NO ES POSIBLE DECLARAR LA FUNCION CALLBACK DE UN "useEffect" DIRECTAMENTE COMO "async"?
"useEffect" espera que el callback retorne opcionalmente una función de limpieza,
pero una función "async" siempre retorna una Promesa, rompiendo así el contrato del hook

Una función declarada como async envuelve implícitamente su retorno en una Promesa.
useEffect, sin embargo, requiere que el valor de retorno sea una función (para la limpieza) o undefined.
Al retornar una Promesa, se viola esta regla.
La forma correcta es definir una función async dentro del efecto y llamarla

```js

    useEffect(() => {
        if (countDown === 0) return;

        const intervalId = setInterval(() => {
            setCountDown((prev) => prev - 1);
        }, 1000);

        return () => {
            clearInterval(intervalId);
        }
    }, [countDown]);

    useEffect(() => {
        if (countDown === 0) {
            setCountDown(5);
            if (light === 'red') {
                setLight('green');
                return;
            }

            if (light === 'yellow') {
                setLight('red');
                return;
            }

            if (light === 'green') {
                setLight('yellow');
                return;
            }
        }
    }, [countDown, light])
```

## 124. Conectar varios "Custom Hooks" entre sí

src\03-Examples\PokemonPage.tsx
src\hooks\useCounter.tsx
src\hooks\usePokemon.ts

```js
export const usePokemon = ({ id }: Props) => {
    const [pokemon, setPokemon] = useState<Pokemon | null>(null);

    const getPokemonById = async (id: number) => {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
        const data = await response.json();

        setPokemon({
            id: id,
            name: data.name,
            imageUrl: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`
        });
    }

    return {
        // Properties
        pokemon
    }
}
```

## 125. Parte 2 - Conectar varios "Custom Hooks"

src\hooks\usePokemon.ts
```js

    const getPokemonById = async (id: number) => {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
        const data = await response.json();

        setPokemon({
            id: id,
            name: data.name,
            imageUrl: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`
        });
    }

    useEffect(() => {
        getPokemonById(id) //<-------------

    }, [id])
```

src\hooks\usePokemon.ts
```ts

    return {
        formattedId: id.toString().padStart(3, '0') //<------------- Rellena con 0's
    }
```

## 126. useRef - Valor que no dispara re-render

useRef 
Referencias mutables que no causan re-render.

src\04-useRef\FocusScreen.tsx
```js

    const inputRef = useRef<HTMLInputElement>(null);

    const handleClick = () => {
        inputRef.current?.select()
        // inputRef.current?.focus()
    }

    <input
        ref={inputRef}
        type="text"
        className="bg-white text-black px-4 py-2 rounded-md"
        autoFocus
    />

    <button
        onClick={handleClick}
        className="bg-blue-500 text-white px-4 py-2 rounded-md cursor-pointer">Set Focus</button>
        
```