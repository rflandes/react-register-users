# Section 4: Primeros pasos en react
Source code: "react-first-steps-main.zip"

* Componentes
* Estructura y nomenclatura
* Hook - useState
* CSS condicional
* Módulos de css
* Impresiones de variables
* Props

# Section 5: Pruebas automáticas - Unit testing
Source code: "react-first-steps-fin-seccion-05.zip"

* Vitest
* Vitest UI
* Índice de cobertura
* Describe y Test
* Espías
* Mock
* Mock sobre componentes
* Depuración en consola
* Snapshots
* Esperar argumentos específicos en funciones
* Integración con Testing Library

# Section 6: GifExpertApp - Application
Source code: "react-ts-gifs-fin-seccion-06.zip"

* Peticiones HTTP
* Debounce
* Manejo de estado
* Comunicación entre componentes
* useEffect
* Variables de entorno
* Fuentes personalizadas

# Section 7: Optimización y despliegue
Source code: "react-ts-gifs-fin-seccion-07.zip"

* Custom Hooks - Hooks personalizados
* DevTools de React
* useRef - Hook propio de React
* Generar versión de producción
* Separación de responsabilidades

# Section 8: Testing - Pruebas sobre GifsApp
Source code: "react-ts-gifs-fin-seccion-08.zip"

* Pruebas sobre hooks
* Pruebas sobre custom hooks
* Pruebas con tareas asíncronas
* Pruebas con tareas que involucran timeouts
* Pruebas sobre axios
* Integrar testing en el proceso de construcción
* Espías
* Sobre escribir funciones para el testing
* Manejo de excepciones


# Section 9: Profundizando Hooks y React
Source code: "react-ts-hooks-app-fin-seccion-09.zip"

* useState
* useRef
* useEffect
* Custom Hooks como:
    * useCounter
    * usePokemon
    * useTrafficLight
* Conectar múltiples custom hooks entre sí

# Section 10. Profundizando Hooks - useReducer
Source code: "react-ts-hooks-app-fin-seccion-10.zip"

En esta sección trabajaremos con el hook "useReducer”, el cual está diseñado para ayudarnos a resolver estados donde una acción puede desencadenar varios cambios de estado simultáneamente, pero también se puede usar para cosas simples también, pero su poder radica en que puedes colocar nombres humanamente legibles para las acciones que cambian el estado.

* Patron reducer
* useReducer hook
* Validadores de esquemas - Zod
* Efectos sobre estados
* LocalStorage y SessionStorage
* Condiciones de los reducers

# Section 11: Memorización y optimizaciones
Source code: "08-react-ts-hooks-app-fin-seccion-11.zip"

* Memorización
* Hooks de memorización como:
*   useMemo
*   useCallback
* useOptimistic para hacer actualizaciones en pantalla rápidas
* useTransaction para evitar bloqueos de UI
* Simular fallos en posteos optimistas para hacer reversiones
* Nueva api Use
* Componente Suspense

# Section 12: Use Context
Source code: "09-react-ts-hooks-app-fin-seccion-12.zip" 

* Hook useContext
* Nueva API - use
* Persistencia de sesiones de usuario
* Rutas de la aplicación
* Rutas privadas y públicas
* Diseño condicional

# Section 13: Single Page Application - SPA (Rutas - Lazy Load - Diseño con AI)
Source Code: "10-react-ts-heroes-app-fin-seccion-13.zip"

* ShadcnUI
* Tailwind
* Utilización de componentes
* Segmentación de código
* LazyLoad
* Estrutura de una paginación

# Section 14: Funcionalidad, caché y optimizaciones
Source Code: "11-react-ts-heroes-app-fin-seccion-14.zip"

* Variables de Entorno
* TanStack Query
* QueryParameters
* Caché
* Custom Hooks especializados
* Paginaciones por categorías

# Section 15: Context API - Búsquedas y favoritos
Source Code: "12-react-ts-heroes-app-fin-seccion-15.zip"

El objetivo es seguir el patrón de delegar la mayor cantidad de lógica a estados fuera de `useState` y `useEffect` para optimizar el rendimiento y, finalmente, preservar el estado al compartir el enlace de la aplicación.


