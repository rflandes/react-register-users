# Section 5: Pruebas automáticas - Unit testing
Source code: "react-first-steps-fin-seccion-05.zip"

* Vitest
* Vitest UI
* Índice de cobertura
* Describe y Test
* Espías
* Mock
* Mock sobre componentes
* Depuración en consola
* Snapshots
* Esperar argumentos específicos en funciones
* Integración con Testing Library

## 51. Configuración Vitest
https://vitest.dev/

> npm install -D vitest

Next, in order to execute the test, add the following section to your package.json:

package.json
```json
{
  "scripts": {
    "test": "vitest",
    "test-ui": "vitest --ui",
    "coverage": "vitest run --coverage"
  }
}
```

## 52. Mis primeras pruebas automáticas
> npm run test

src/helpers/math.helper.ts
```js
export const add = (a: number, b: number) => {
  return a + b;
}

export const substract = (a: number, b: number) => {
  return a - b;
}

export const multiply = (a: number, b: number) => {
  return a * b;
}

export const divide = (a: number, b: number) => {
  return a / b;
}
```

By default, tests must contain .test. or .spec. in their file name.


src/helpers/math.helper.test.ts
```js
import { expect, test } from 'vitest'
import { add } from './math.helper';

test('should add two positive numbers', () => {
  // ! 1. Arrange
  const a = 1;
  const b = 2;

  // ! 2. Act
  const result = add(a, b);

  // ! 3. Assert
  expect(result).toBe(a + b);
});


```

## 53. Agrupar pruebas similares
src/helpers/math.helper.test.ts
```js
import { describe, expect, test } from 'vitest'
import { add } from './math.helper';

describe('add', () => {
  test('should add two positives numbers', () => {
    // ! 1. Arrange
    const a = 1;
    const b = 2;

    // ! 2. Act
    const result = add(a, b);

    // ! 3. Assert
    expect(result).toBe(a + b);
  });

  test('should add two negative numbers', () => {
    // ! 1. Arrange
    const a = -2;
    const b = -4;

    // ! 2. Act
    const result = add(a, b);

    // ! 3. Assert
    expect(result).toBe(a + b);
  });
});

```

## 54. Pruebas sobre componentes en React
### Testing Library
https://testing-library.com/

> npm install --save-dev @testing-library/react @testing-library/dom @types/react @types/react-dom


vite.config.ts
```js
// import { defineConfig } from 'vite';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  plugins: [react()],
  test: {                     ////// <---------------------
    environment: 'jsdom',     ////// <---------------------
    globals: true,
  },
});

```

> npm run test
do you want to install isdom? -- yes


> npm run test

src/MyAwesomeApp.test.tsx
```js
import { describe, expect, test } from 'vitest'
import { render, screen } from '@testing-library/react';

import { MyAwesomeApp } from './MyAwesomeApp';

describe('MyAwesomeApp', () => {
  test('should render firstName and lastName', () => {
    const { container } = render(<MyAwesomeApp />);
    // screen.debug();
    // console.log(container.innerHTML);

    const h1 = container.querySelector('h1');
    const h3 = container.querySelector('h3');

    expect(h1?.innerHTML).toContain('Fernando');
    expect(h3?.innerHTML).toContain('Herrera');
  });
});

```

## 55. Buscar elementos en el componente renderizado

src/MyAwesomeApp.test.tsx
```js

describe('MyAwesomeApp', () => {
  test('should render firstName and lastName - screen', () => {
    render(<MyAwesomeApp />);
    screen.debug();
    // console.log(container.innerHTML);

    // const h1 = screen.getByRole('heading', {
    //   level: 1,
    // });
    const h1 = screen.getByTestId('first-name-title');
    expect(h1.innerHTML).toContain('Fernando');
  });

});

```

## 56. Evaluar snapshot
src/MyAwesomeApp.test.tsx
```js

describe('MyAwesomeApp', () => {

  test('should match snapshot', () => {
    const { container } = render(<MyAwesomeApp />);
    expect(container).toMatchSnapshot();
  });

  test('should match snapshot', () => {
    render(<MyAwesomeApp />);
    expect(screen.getByTestId('div-app')).toMatchSnapshot();
  });

});

```

## 57. Pruebas en el componente ItemCounter
src/shopping-cart/ItemCounter.test.tsx
```js
import { render, screen } from '@testing-library/react';
import { describe, expect, test } from 'vitest';
import { ItemCounter } from './ItemCounter';

describe('ItemCounter', () => {
  
  test('should render with default values', () => {
    // ! 1. Arrange
    const name = 'Control de Nintendo';

    // ! 2. Act
    render(<ItemCounter name={name} />);

    // ! 3. Assert
    expect(screen.getByText(name)).toBeDefined();
    expect(screen.getByText(name)).not.toBeNull();
  });

  test('should render with custom quantity', () => {
    const name = 'Control de Nintendo';
    const quantity = 10;

    render(<ItemCounter name={name} quantity={quantity} />);

    expect(screen.getByText(quantity)).toBeDefined();
  });
});

```

## 58. Disparar eventos
src/shopping-cart/ItemCounter.test.tsx
```js
/* ----- */
import { fireEvent } from '@testing-library/react';

describe('ItemCounter', () => {
  /* ----- */
  test('should increase count when +1 button is pressed', () => {

    render(<ItemCounter name={'Test item'} quantity={1} />);
    const [buttonAdd] = screen.getAllByRole('button');
    fireEvent.click(buttonAdd);

    expect(screen.getByText('2')).toBeDefined();
  });

  test('should decrease count when -1 button is pressed', () => {
    const quantity = 5;

    render(<ItemCounter name={'Test item'} quantity={quantity} />);
    const [, buttonSubtract] = screen.getAllByRole('button');
    fireEvent.click(buttonSubtract);

    expect(screen.getByText('4')).toBeDefined();
  });

});
```
## 59. Comprobar estilos

src/shopping-cart/ItemCounter.test.tsx
```js
/* ----- */

describe('ItemCounter', () => {
  /* ----- */

  test('should change to red when count is 1', () => {
    const quantity = 1;
    const name = 'Test item';

    render(<ItemCounter name={name} quantity={quantity} />);
    const itemText = screen.getByText(name);

    expect(itemText.style.color).toBe('red');
  });
});
```
## 60. Pruebas en "FirstStepsApp"

src/FirstStepsApp.test.tsx
```js
import { render } from '@testing-library/react';
import { describe, expect, test } from 'vitest';

import { FirstStepsApp } from './FirstStepsApp';

describe('FirstStepsApp', () => {

  test('should match snapshot', () => {
    const { container } = render(<FirstStepsApp />);

    expect(container).toMatchSnapshot();
  });

});
```
## 61. Componentes ficticios - Mock Components
src/FirstStepsApp.test.tsx
```js
/* ----- */
import { afterEach, vi } from 'vitest';

const mockItemCounter = vi.fn((_props: unknown) => {
  return <div data-testid="ItemCounter" />;
});

vi.mock('./shopping-cart/ItemCounter', () => ({
  ItemCounter: (props: unknown) => mockItemCounter(props),
}));

// vi.mock('./shopping-cart/ItemCounter', () => ({
// ItemCounter: (props: unknown) => (
// <div
//   data-testid="ItemCounter"
//   name={props.name}
//   quantity={props.quantity}
// />
// ),
// }));

describe('FirstStepsApp', () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  test('should render the correct number of ItemCounter components', () => {
    
    render(<FirstStepsApp />);
    const itemCounters = screen.getAllByTestId('ItemCounter');

    expect(itemCounters.length).toBe(3);
  });

  test('should render ItemCounter with correct props', () => {
    render(<FirstStepsApp />);

    expect(mockItemCounter).toHaveBeenCalledTimes(3);
    expect(mockItemCounter).toHaveBeenCalledWith({
      name: 'Nintendo Switch 2',
      quantity: 1,
    });
    expect(mockItemCounter).toHaveBeenCalledWith({
      name: 'Pro Controller',
      quantity: 2,
    });
    expect(mockItemCounter).toHaveBeenCalledWith({
      name: 'Super Smash',
      quantity: 5,
    });
  });

});


```

## 63. Indice de cobertura
package.json
```json
{
  "scripts": {
    "test:ui": "vitest --ui",
    "coverage": "vitest run --coverage"
  },
}
```

> npm run test:ui
> npm run coverage

coverage/index.html