# Section 10. Profundizando Hooks - useReducer
Source code: "react-ts-hooks-app-fin-seccion-10.zip"

En esta sección trabajaremos con el hook "useReducer”, el cual está diseñado para ayudarnos a resolver estados donde una acción puede desencadenar varios cambios de estado simultáneamente, pero también se puede usar para cosas simples también, pero su poder radica en que puedes colocar nombres humanamente legibles para las acciones que cambian el estado.

* Patron reducer
* useReducer hook
* Validadores de esquemas - Zod
* Efectos sobre estados
* LocalStorage y SessionStorage
* Condiciones de los reducers

## 131. Continuación del proyecto - useReducer

https://ui.shadcn.com/

Instalación y configuración
tsconfig.json
```json
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
```

tsconfig.app.json
```json

```


```bash
npm add -D @types/node
```

vite.config.ts

```js
import path from "path"
import tailwindcss from "@tailwindcss/vite"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
})
```

Run the shadcn init command to setup your project:
```bash
npx shadcn@latest init
```

Add Components
You can now start adding components to your project.
```bash
npx shadcn@latest add
```

## 132. ShadcnUI - ¿Que acabamos de instalar?

Sites para construir proyectos
https://v0.app/
https://lovable.dev/

## 133. Lista de tareas con useState
src\05-useReducer\TaskApp.tsx
```js
const addTodo = () => {
        if (inputValue.trim().length === 0) return;

        const newTodo: Todo = {
            id: Date.now(),
            text: inputValue.trim(),
            completed: false
        };

        setTodos([...todos, newTodo]);
        // setTodos((prev) => [... prev, newTodo]);

        setInputValue('');
    };

    const toggleTodo = (id: number) => {
        const updatedTodos = todos.map((todo) => {
            if (todo.id === id) {
                return { ...todo, completed: !todo.completed };
            }
            return todo;
        });
        setTodos(updatedTodos);
    };

    const deleteTodo = (id: number) => {
        setTodos(todos.filter(todo => todo.id !== id))
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') addTodo();
    };
```



## 134. Patrón Reducer

Función pura:
Una función pura en React es una función (o un componente) que siempre devuelve la misma salida cuando se le dan las mismas entradas y no causa efectos secundarios

Características de una función pura
1. Misma entrada, misma salida:
Dada una entrada específica, una función pura siempre producirá el mismo resultado. 
2. Sin efectos secundarios:
Una función pura no modifica ningún estado externo o variable que exista fuera de su propio alcance. 

src\05-useReducer\reducer\tasksReducer.ts
```js
interface Todo {
    id: number;
    text: string;
    completed: boolean;
}

interface TaskState {
    todos: Todo[];
    length: number;
    completed: number;
    pending: number;
}

export type TaskAction =
    { type: 'ADD_TODO', payload: string }
    | { type: 'TOGGLE_TODO', payload: number }
    | { type: 'DELETE_TODO', payload: number };

export const tasksReducer = (
    state: TaskState,
    action: TaskAction): TaskState => {

    return state;
}
```

## 135. Configuración de la función reducer

src\05-useReducer\reducer\tasksReducer.ts
```js

export const tasksReducer = (
    state: TaskState,
    action: TaskAction
): TaskState => {

    switch (action.type) {
        case 'ADD_TODO': {
            const newTodo: Todo = {
                id: Date.now(),
                text: action.payload,
                completed: false
            };

            return {
                ...state,
                todos: [...state.todos, newTodo]
            };
        }
        case 'DELETE_TODO':
            return state;
        case 'TOGGLE_TODO':
            return state;

        default:
            return state;
    }
}
```

## 137. Controlar estados complejos - useReducer

src\05-useReducer\TaskApp.tsx
```js
import { getTaskInitialState, tasksReducer } from './reducer/tasksReducer';

    const [state, dispatch] = useReducer(tasksReducer, getTaskInitialState());
    const { todos, completed: completedCount, length: totalCount, } = state;

    const addTodo = () => {
        if (inputValue.trim().length === 0) return;

        dispatch({type: 'ADD_TODO', payload: inputValue.trim()});

        setInputValue('');
    };
```

## 138. Persistencia local - LocalStorage

src\05-useReducer\TaskApp.tsx
```js
    useEffect(() => {
        localStorage.setItem('tasks-state', JSON.stringify(state));
    }, [state]);
```

## 139. Validadores de objetos - Zod

Zod
TypeScript-first schema validation with static type inference
https://zod.dev/

```bash
npm install zod
```

src\05-useReducer\reducer\tasksReducer.ts
```js
import * as z from "zod";


const TodoSchema = z.object({
    id: z.number(),
    text: z.string(),
    completed: z.boolean()
});

const TaskStateSchema = z.object(
    {
        todos: z.array(TodoSchema),
        length: z.number(),
        completed: z.number(),
        pending: z.number(),
    }
);


export const getTaskInitialState = () => {

    const localStorageState = localStorage.getItem('tasks-state');

    if (!localStorageState) {
        return {
            todos: [],
            completed: 0,
            pending: 0,
            length: 0
        }
    }

    // Validar mediante Zod
    const result = TaskStateSchema.safeParse(JSON.parse(localStorageState));

    if (result.error) {
        console.log(result.error);
        return {
            todos: [],
            completed: 0,
            pending: 0,
            length: 0
        }
    }

    // return JSON.parse(localStorageState);
    return result.data;
}

```

# Section 11: Memorización y optimizaciones
Source code: "08-react-ts-hooks-app-fin-seccion-11.zip"

* Memorización
* Hooks de memorización como:
*   useMemo
*   useCallback
* useOptimistic para hacer actualizaciones en pantalla rápidas
* useTransaction para evitar bloqueos de UI
* Simular fallos en posteos optimistas para hacer reversiones
* Nueva api Use
* Componente Suspense

## 149. Continuación de aplicación

src\06-memos\MemoHooks.tsx
src\06-memos\ui\MyTitle.tsx
src\06-memos\ui\MySubTitle.tsx

## 150. React Memo - Función de memorización

src\06-memos\ui\MyTitle.tsx
```js
export const MyTitle = React.memo(({ title }: Props) => {
})
```

## 151. useCallback - Memorización de funciones
src\06-memos\ui\MySubTitle.tsx
```js

interface Props {
    subtitle: string,

    callMyAPI: () => void,
}

export const MyTitle = React.memo(({ title,, callMyAPI }: Props) => {
            <button 
                onClick={callMyAPI}
                className="bg-indigo-500 text-white px-2 py-1 rounded-md cursor-pointer"
                >Llamar a función
            </button>
})
```


src\06-memos\MemoHooks.tsx
```js

    const handleMyAPICall = useCallback(() => {
        console.log('Llamar a mi API', subtitle);
    }, [subtitle]);

    
            <button
                className='bg-blue-500 text-white px-4 py-2 rounded-md cursor-pointer'
                onClick={() => setSubtitle('World')}
            >
                Cambiar subtitulo
            </button>

```

## 152. useMemo - Memorización de valores

useMemo
Memoriza valores para evitar volverlos a calcular entre re-renders

src\06-memos\MemoCounter.tsx
```js

```

## 153. useOptimistic - Preparación del ejercicio
src\07-useOptimistic\InstragromApp.tsx
```js

    const handleAddComment = async (formData: FormData) => {
        const messageText = formData.get('post-message') as string;
        console.log('Nuevo comentario', messageText);

        await new Promise((resolve) => setTimeout(resolve, 3000));

        setComments((prev) => [
            ...prev,
            {
                id: new Date().getTime(),
                text: messageText
            }
        ])
    };
```

## 154. useOptimistic

Muestra valores optimistas antes de que una acción sea resuelta.

src\07-useOptimistic\InstragromApp.tsx

```js
const [optimisticComments, addOptimisticComment] = useOptimistic(comments,(currentComments, newCommentText: string) => {
        return [...currentComments, {
            id: new Date().getTime(),
            text: newCommentText,
            optimistic: true
        }]
    })

    const handleAddComment = async (formData: FormData) => {
        const messageText = formData.get('post-message') as string;

        addOptimisticComment(messageText);

        await new Promise((resolve) => setTimeout(resolve, 3000));

        setComments((prev) => [
            ...prev,
            {
                id: new Date().getTime(),
                text: messageText
            }
        ])
    };
```

## 155. useTransition

Permite renderizar partes del UI en el background, pueden ser vistas como actualizaciones no urgentes.

src\07-useOptimistic\InstragromApp.tsx
```js
    const [isPending, startTransition] = useTransition();

    const handleAddComment = async (formData: FormData) => {
        const messageText = formData.get('post-message') as string;

        addOptimisticComment(messageText);

        // console.log('Nuevo comentario', messageText);
        startTransition(async () => {
            await new Promise((resolve) => setTimeout(resolve, 3000));

            setComments((prev) => [
                ...prev,
                {
                    id: new Date().getTime(),
                    text: messageText
                }
            ])
        });
    };

```

## 156. Simular fallo en useOptimistic + sonner

Envío de notificaciones en pantalla
https://sonner.emilkowal.ski/

```bash
npm install sonner
```

src\main.tsx
```js
import { Toaster, toast } from 'sonner'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Toaster />
    <InstagromApp />
  </StrictMode>,
)

```

src\07-useOptimistic\InstragromApp.tsx
```js

            toast('Error al agregar el comentario', {
                description: 'Intente nuevamente',
                duration: 10_000,
                position: 'top-right',
                action: {
                    label: 'Cerrar',
                    onClick: () => toast.dismiss()
                }
            });
```

## 157. Use API + Suspense - Preparación del ejercicio
src\08-use-suspense\ClientInformation.tsx
src\08-use-suspense\api\get-user.action.ts

## 158. Use API + Suspense en acción
Componente <Suspense>
Permite desplegar un contenido hasta que sus hijos terminen de cargar.

```js
<Suspense fallback={<Loading>}>
    <Albums>
</Suspense>
```

* React API - use
"use" no es un hook

Permite leer un valor de un recurso como una promesa o contexto, suspendiendo la creación hasta tener una resolución. Va de la mano del componente Suspense