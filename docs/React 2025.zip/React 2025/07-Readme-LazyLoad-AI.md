# Section 13: Single Page Application - SPA (Rutas - Lazy Load - Diseño con AI)
Source Code: "10-react-ts-heroes-app-fin-seccion-13.zip"

* ShadcnUI
* Tailwind
* Utilización de componentes
* Segmentación de código
* LazyLoad
* Estrutura de una paginación

## 175. Creación de proyecto - HeroesApp

```bash
npm create vite@latest
```

Project name: 05-heroes-app
Select a framework: React
Select a variant: Typescript + SWC

shadcn
https://ui.shadcn.com/

install
> npm install tailwindcss @tailwindcss/vite

src\index.css
```css
@import "tailwindcss";
```

Edit tsconfig.json file
```json
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
```

Edit tsconfig.app.json file
```json
{
  "compilerOptions": {
    // ...
    "baseUrl": ".",
    "paths": {
      "@/*": [
        "./src/*"
      ]
    }
    // ...
  }
}
```

Update vite.config.ts

> npm install -D @types/node
```js
import path from "path"
import tailwindcss from "@tailwindcss/vite"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
})
```

Run the shadcn init command to setup your project:
> npx shadcn@latest init

Add Components
You can now start adding components to your project
> npx shadcn@latest add button

## 176. Generardores visuales con AI

https://v0.app/
https://lovable.dev/
https://bolt.new/

## 177. Creación de rutas y pantallas

React Router
https://reactrouter.com/

Install React Router
> npm i react-router

Create a router
src\router\app.router.tsx
```js
import { createBrowserRouter } from "react-router";
import { HomePage } from '../heroes/pages/home/HomePage';

export const router = createBrowserRouter([
    {
        path: '/',
        element: <HomePage />
    }
]);
```

Pass it to RouterProvider:
src\HeroesApp.tsx
```js

export const HeroesApp = () => {
    return (
        <>
            <RouterProvider router={heroesRouter} />
        </>
    )
}
```

## 178. Componente "Layout"
src\router\app.router.tsx
```js

export const appRouter = createBrowserRouter([
    {
        path: '/',
        element: <HeroesLayout />,          ///
        children: [                         ///
            {
                index: true,                ///
                element: <HomePage />
            },
            {
                path: 'heroes/1',
                element: <HeroPage />
            },
            {
                path: 'search',
                element: <SearchPage />
            },
        ]
    },
    {
        path: '/admin',
        element: <AdminPage />
    },
]);
```

src\heroes\layouts\HeroesLayout.tsx
```js
export const HeroesLayout = () => {
    return (
        <div className="bg-red-500">
            <Outlet />
        </div>
    )
}

```

## 179. Lazy Load - Carga Perezosa

src\heroes\pages\search\SearchPage.tsx
```js
export const SearchPage = () => {
    return (
        <div>SearchPage</div>
    )
}

export default SearchPage;
```

src\router\app.router.tsx
```js 
// import { SearchPage } from "@/heroes/pages/search/SearchPage";

const SearchPage = lazy(() => import('@/heroes/pages/search/SearchPage'));
```

## 180. Pensemos en componentes reutilizables
src\components\custom\CustomJumbotron.tsx
src\heroes\components\HeroStats.tsx

## 181. Parte 2 - Pensemos en componentes

src\heroes\components\HeroStatCard.tsx
cosas importantes sobre como pasar información del children
y como pasar informacion de tipo Element (icon)
```js

interface Props extends PropsWithChildren {
    title: string;
    icon: React.ReactNode;
}

export const HeroStatCard = ({ title, icon, children }: Props) => {
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
                {icon}
            </CardHeader>
            <CardContent>{children}</CardContent>
        </Card>
    );
};
```
src\heroes\components\HeroStats.tsx

## 182. Componentes de búsqueda

src\heroes\pages\search\ui\SearchControls.tsx

## 183. Grid de personajes

Personalizar progress para agregar la propiedad activeColor

src\components\ui\progress.tsx
```js
function Progress({
  className,
  value,
  activeColor = 'bg-primary',
  ...props
}: React.ComponentProps<typeof ProgressPrimitive.Root> & { activeColor: string }) {
}
```

cn = funcion para unir diferentes clases de tailwind
src\components\ui\progress.tsx
```js
<ProgressPrimitive.Indicator
        data-slot="progress-indicator"
        className={cn(activeColor, "h-full w-full flex-1 transition-all")}
        style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
      />
```

src\heroes\components\HeroGridCard.tsx
Personalizar el color activo
```js
<Progress value={100} className="h-2" activeColor="bg-orange-500" />
```

## 184. Shadcn Tabs

TabsContent

src\heroes\pages\home\HomePage.tsx
```js
 <TabsContent value='all'>
  {/* Mostrar todos los personajes */}
  <h1>Todos los personajes</h1>
  <HeroGrid />
</TabsContent>
<TabsContent value='favorites'>
  {/* Mostrar todos los favoritos */}
  <h1>Favoritos!!</h1>
  <HeroGrid />
</TabsContent>
<TabsContent value='heroes'>
  {/* Mostrar todos los heroes */}
  <h1>Heroes</h1>
  <HeroGrid />
</TabsContent>
<TabsContent value='villains'>
  {/* Mostrar todos los villanos */}
  <h1>Villanos!!</h1>
  <HeroGrid />
</TabsContent>
```

## 185. Componente de paginación

crear un arreglo

src\components\custom\CustomPagination.tsx
```js
{
    Array.from({ length: totalPages }).map((_, index) => (
        <Button variant="default" size="sm">
            1
        </Button>
    ))
}
```

## 186. Menú superior - Identificar ruta activa

Shadcn
https://ui.shadcn.com/docs/components/navigation-menu

Installation
> npx shadcn@latest add navigation-menu

src\components\custom\CustomMenu.tsx
```js

export const CustomMenu = () => {
    return (
        <NavigationMenu>
            <NavigationMenuList>
                <NavigationMenuItem>
                    <NavigationMenuLink asChild>
                        <Link to="/">Inicio</Link>
                    </NavigationMenuLink>
                </NavigationMenuItem>
            </NavigationMenuList>
        </NavigationMenu>
    )
}
```

## 187. Breadcrumb - Implementar componente
src\components\custom\CustomBreadcrumbs.tsx
