# Section 4: Primeros pasos en react
Source code: "react-first-steps-main.zip"

* Componentes
* Estructura y nomenclatura
* Hook - useState
* CSS condicional
* Módulos de css
* Impresiones de variables
* Props

## 34. Primer proyecto en React
> npm create vite
name the project as first-steps
select React
select typeScript + SWC
> npm install
> npm run dev

src/App.tsx
```js
function App() {
  return (
    <>
      <h1>Hola Mundo</h1>
      <p>Hola, estudiante</p>
    </>
  )
}
```

## 35. Extructura de directorios

vite.config.ts
```js
import react from '@vitejs/plugin-react-swc'
// SWC = Speedy Web Compiler
// SWC remplaza la utilización de Babel
```

## 37. Mi primer componente

src/FirstStepsApp.tsx
```js
export function FirstStepsApp() {
  
  return (
    <>
      <h1>Hola Mundo</h1>
      <p>Esto es un párrafo</p>

      <button>Click Me</button>

      <div>
        <h2>Hola dentro de un div</h2>
      </div>
    </p>
  );
}

```


src/Main.tsx
```js
/*----*/
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <FirstStepsApp />
  </StrictMode>
);
```
## 39. Impresion de variables

src/MyAwesomeApp.tsx
```js
import { CSSProperties } from 'react';

const firstName = 'Fernando';
const lastName = 'Herrera';

const favoriteGames = ['Elden Ring', 'Smash', 'Metal Gear'];

const isActive = false;

const address = {
  zipCode: 'ABC-123',
  country: 'Canadá',
};

const myStyles: CSSProperties = {
  backgroundColor: '#fafafa',
  borderRadius: 20,
  padding: 10,
  marginTop: 30,
};

export const MyAwesomeApp = () => {
  return (
    <>
      <h1> {firstName} </h1>
      <h3> {lastName} </h3>

      <p>{favoriteGames.join(', ')}</p>
      <p>{2 + 2}</p>

      <h1>{isActive ? 'Activo' : 'No activo'}</h1>
      
      <p style={myStyles}>{JSON.stringify(address)}</p>

    </>
  );
};
```
## 41. Componente - ItemCounter

src/shopping-cart/ItemCounter.tsx
```js

export const ItemCounter = () => {
  return (
    <section
      style={{
        display: flex;
        alignItems: center;
        gap: 10;
        marginTop: 10;
        }}
    >
      <span
        style={{
          width: 150
        }}
      >
        Nintendo Switch 2
      </span>
      <button>+1</button>
      <span>10</span>
      <button>-1</button>
    </section>
  );
};
```

## 42. Propiedades del componente - Props

src/shopping-cart/ItemCounter.tsx
```js

interface Props {
  name: string;
}

export const ItemCounter = ({name}: Props) => {

/*  */
      <span
        style={{
          width: 150
        }}
      >
        {name}
      </span>
/*  */
      
}
```

## 43. Mostrar listados de elementos
src/FirstStepsApp.tsx
```js
interface ItemInCart {
  productName: string;
  quantity: number;
}

const itemsInCart: ItemInCart[] = [
  {productName: 'Nintendo Switch 2', quantity = 1},
  {productName: 'Pro Controller', quantity = 2},
  {productName: 'Super Smash', quantity = 5},

  export function FirstStepsApp() {
    return (
      <>
        <h1>Carrito de Compras</h1>
        { itemsInCart.map((productName, quantity) => {
            <ItemCounter key={productName} name={productName} quantity={quantity} />
          }
        )}
      </h1>
    )
  }
]

```
## 44. Eventos de los elementos

src/shopping-cart/ItemCounter.tsx
```js

export const ItemCounter = ({ name, quantity = 1 }: Props) => {
  const [count, setCount] = useState(quantity);

  const handleAdd = () => {
    setCount(count + 1);
  };

  const handleSubtract = () => {
    if (count === 1) return;

    setCount(count - 1);
  };

  return (
    <section
      style={{
        display: flex;
        alignItems: center;
        gap: 10;
        marginTop: 10;
        }}
    >
      <span
        style={{
          width: 150
        }}
      >
        Nintendo Switch 2
      </span>
      <button onClick={handleAdd} >+1</button>
      <span>10</span>
      <button  onClick={handleSubtract}>-1</button>
    </section>
  );
};
```

## 46. Archivos de CSS

Código valido css style utilizando
className 
```js
    <section className="item-row">
```

src/shopping-cart/ItemCounter.css
```css
.item-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
}

.item-text {
  width: 150px;
}
```

Código valido css module style utilizando
className 
```js
import styles from './ItemCounter.module.css';

    <section className={styles.itemRow}>
```


src/shopping-cart/ItemCounter.module.css
```css
.itemRow {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
}

.item-text {
  width: 150px;
}

.red {
  color: red;
}
```