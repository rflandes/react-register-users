
export const AdminPage = () => {
    return (
        <div>AdminPage</div>
    )
}
