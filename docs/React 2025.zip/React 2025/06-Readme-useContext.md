
# Section 12: Use Context
Source code: "09-react-ts-hooks-app-fin-seccion-12.zip" 

* Hook useContext
* Nueva API - use
* Persistencia de sesiones de usuario
* Rutas de la aplicación
* Rutas privadas y públicas
* Diseño condicional

## 163. React Router - Manejo de rutas

Navegación en React
https://reactrouter.com/

```bash
npm i react-router
```

src\09-useContext\router\app.router.tsx
```js

import { createBrowserRouter } from "react-router";
import { AboutPage } from "../pages/about/AboutPage";

export const appRouter = createBrowserRouter([{
        path: "/",
        element: <AboutPage />,
    },
    {
        path: "*",
        element: <Navigate to='/' />,
    },
]);
```
src\09-useContext\ProfessionalApp.tsx
```js
export const ProfessionalApp = () => {
    return (
        <div className='bg-gradient flex flex-col'>
            <RouterProvider router={appRouter} />
        </div>
    )
}
```

## 164. Navegar entre pantallas - Diseño de páginas

Para redirigir el url en lugar de "<a href="/profile">Profile</a>"
utilizar Link "<Link to="/profile">Profile</Link>"

src\09-useContext\pages\about\AboutPage.tsx

## 165. Contextos y proveedores en React

src\09-useContext\context\UserContext.tsx
```js
import { type PropsWithChildren } from "react"

export const UserContextProvider = ({ children }: PropsWithChildren) => {
    return (<>{children}</>)
}
```

src\09-useContext\ProfessionalApp.tsx
```js
export const ProfessionalApp = () => {
    return (
        <UserContextProvider>
            <div className='bg-gradient flex flex-col'>
                <RouterProvider router={appRouter} />
            </div>
        </UserContextProvider>
    )
}
```

## 166. Contexto de usuario - Información global

src\09-useContext\context\UserContext.tsx
```js

type AuthStatus = 'checking' | 'authenticated' | 'not-authenticated';

interface UserContextProps {
    // state
    authStatus: AuthStatus;
    user: User | null;

    // Methods
    login: (userId: number) => boolean;
    logout: () => void;
}

export const UserContext = createContext({} as UserContextProps);

export const UserContextProvider = ({ children }: PropsWithChildren) => {

    const [authStatus, setAuthStatus] = useState<AuthStatus>('checking');
    const [user, setUser] = useState<User | null>(null);

    const handleLogin = (userId: number): boolean => {
        console.log({ userId });
        return true
    }

    const handleLogout = () => {
        console.log('Logout...');
    }

    return (<UserContext value={{
        authStatus: authStatus,
        user: user,
        login: handleLogin,
        logout: handleLogout
    }}>{children}</UserContext>)
}
```

## 167. Consumir el contexto

src\09-useContext\context\UserContext.tsx
```js

    const handleLogin = (userId: number): boolean => {
        const user = users.find((user) => user.id === userId);
        if (!user) {
            console.log(`User not found> ${userId}`);
            setUser(null);
            setAuthStatus('not-authenticated');
            return false;
        }
        setUser(user);
        setAuthStatus('authenticated');

        return true
    }

    const handleLogout = () => {
        console.log('Logout...');
        setUser(null);
        setAuthStatus('not-authenticated');
    }
```

Como utilizar el contexto
src\09-useContext\pages\auth\LoginPage.tsx

```js

export const LoginPage = () => {
    const { login } = useContext(UserContext);

}
```
## 168. Persistencia del usuario
src\09-useContext\context\UserContext.tsx
```js
        localStorage.setItem('userId', userId.toString());
        localStorage.removeItem('userId');

```
## 169. Diseño condicional dependiendo de la sesión

src\09-useContext\pages\about\AboutPage.tsx
```js

    <div className="flex flex-col gap-2">
        {
            isAuthenticated && (
                <Link to="/profile" className="hover:text-blue-500 underline text-2xl">Profile</Link>
            )
        }
        {
            isAuthenticated ? (
                <Button onClick={logout} variant={"destructive"} className="mt-4">
                    Salir
                </Button>)
                : (
                    <Link to="/login" className="hover:text-blue-500 underline text-2xl">Iniciar Sesión</Link>
                )
        }
    </div>
```

## 170. Rutas privadas y públicas

src\09-useContext\router\PrivateRoute.tsx
```js

interface Props {
    element: JSX.Element
}
export const PrivateRoute = ({ element }: Props) => {
    const { authStatus } = use(UserContext);

    if (authStatus === 'checking') {
        return <div>Loading...</div>
    }

    if (authStatus === 'authenticated') {
        return element;
    }

    return <Navigate to="/login" replace />
}

```

src\09-useContext\router\app.router.tsx
```js

    {
        path: "/profile",
        element: <PrivateRoute element={<ProfilePage />} />,
    },
```