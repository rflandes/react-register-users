# Section 8: Testing - Pruebas sobre GifsApp
Source code: "react-ts-gifs-fin-seccion-08.zip"

* Pruebas sobre hooks
* Pruebas sobre custom hooks
* Pruebas con tareas asíncronas
* Pruebas con tareas que involucran timeouts
* Pruebas sobre axios
* Integrar testing en el proceso de construcción
* Espías
* Sobre escribir funciones para el testing
* Manejo de excepciones

## 95. Configuración de pruebas

* Instalar dependencias Testing 

1. [Vitest](https://vitest.dev/guide/)

```bash
npm install --save-dev vitest jsdom
```

2. React [Testing Library](https://testing-library.com/docs/react-testing-library/intro)

```bash
npm install --save-dev @testing-library/react @testing-library/dom
```

- Todo en un sólo comando

```bash
npm install --save-dev @testing-library/react @testing-library/dom vitest jsdom
```

3. Crear estos scripts en el `package.json`

```json
"scripts": {
  "test": "vitest",
  "test:ui": "vitest --ui",
  "coverage": "vitest run --coverage"
}
```

4. Configurar `vite.config.ts`
```ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react-swc';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
  },
});
```

src\GifsApp.test.tsx

## 96. Pruebas sobre "CustomHeader"

src\shared\components\CustomHeader.test.tsx
```js
    expect(screen.getByText(title)).toBeDefined();
```

```js
    expect(screen.getByText(description)).toBeDefined();
    expect(screen.getByRole('paragraph')).toBeDefined();
    expect(screen.getByRole('paragraph').innerHTML).toBe(description);
```

```js
    const { container } = render(<CustomHeader title={title} />);
    const divElement = container.querySelector('.content-center');
    const h1 = divElement?.querySelector('h1');
    const p = divElement?.querySelector('p');

    expect(h1?.innerHTML).toBe(title);
    expect(p).toBeNull();

```

## 97. Pruebas sobre "Custom Hooks"

src\counter\hooks\useCounter.test.ts
```js
    const { result } = renderHook(() => useCounter());

    expect(result.current.counter).toBe(10);
```
```js
  test('should increment counter when handleAdd is called', () => {
    const { result } = renderHook(() => useCounter());

    act(() => {
      result.current.handleAdd();
    });

    expect(result.current.counter).toBe(11);
  });
```

## 99. Componentes con "custom hooks"
src\counter\components\MyCounterApp.test.tsx
```ts
    expect(screen.getByRole('heading', { level: 1 }).innerHTML).toContain(
      `counter: 10`
    );
    expect(screen.getByRole('button', { name: '+1' })).toBeDefined();
```

```ts
    const labelH1 = screen.getByRole('heading', { level: 1 });
    const button = screen.getByRole('button', { name: '+1' });

    fireEvent.click(button);

    expect(labelH1.innerHTML).toContain('counter: 11');
```

## 100. Simular estado de un "Custom Hook"
src\counter\components\MyCounterApp2.test.tsx
```js
import { vi } from 'vitest';

// import { useCounter } from '../hooks/useCounter';

const handleAddMock = vi.fn();
const handleSubtractMock = vi.fn();
const handleResetMock = vi.fn();

vi.mock('../hooks/useCounter', () => ({
  useCounter: () => ({
    counter: 40,
    handleAdd: handleAddMock,
    handleReset: handleResetMock,
    handleSubtract: handleSubtractMock,
  }),
}));


describe('MyCounterApp', () => {
  test('should render the component', () => {
    render(<MyCounterApp />);

    expect(screen.getByRole('heading', { level: 1 }).innerHTML).toContain(
      `counter: 40`
    );

    expect(2).toBe(2);

    expect(screen.getByRole('button', { name: '+1' })).toBeDefined();
    expect(screen.getByRole('button', { name: '-1' })).toBeDefined();
    expect(screen.getByRole('button', { name: 'Reset' })).toBeDefined();
  });
});

```

```js
    const button = screen.getByRole('button', { name: '+1' });

    fireEvent.click(button);

    expect(handleAddMock).toHaveBeenCalled();
    expect(handleAddMock).toHaveBeenCalledTimes(1);
    expect(handleSubtractMock).not.toHaveBeenCalled();
    expect(handleResetMock).not.toHaveBeenCalled();

```

## 101. Prueba sobre instancias de Axios

src\gifs\api\giphy.api.test.ts
```js
    const params = giphyApi.defaults.params;

    expect(giphyApi.defaults.baseURL).toBe('https://api.giphy.com/v1/gifs');
    expect(params.lang).toBe('es');
    expect(params.api_key).toBe(import.meta.env.VITE_GIPHY_API_KEY);

    expect(params).toStrictEqual({
      lang: 'es',
      api_key: import.meta.env.VITE_GIPHY_API_KEY,
    });
```

## 102. Pruebas sobre acción - getGifsByQuery
src\gifs\actions\get-gifs-by-query.action.test.ts
```js
    const gifs = await getGifsByQuery('goku');
    // console.log(gifs);
    
    const [gif1] = gifs;

    expect(gifs.length).toBe(10);

    expect(gif1).toStrictEqual({
      id: expect.any(String),
      height: expect.any(Number),
      width: expect.any(Number),
      title: expect.any(String),
      url: expect.any(String),
    });

```

## 103. Axios mock adapter - Controlar resultados de Axios

npm axios-mock-adapter
https://www.npmjs.com/package/axios-mock-adapter


```bash
npm install axios-mock-adpter --save-dev
```

tests\mocks\giphy.response.data.ts
tests\mocks\gifs.data.ts

src\gifs\actions\get-gifs-by-query.action.test.ts
```js
import AxiosMockAdapter from 'axios-mock-adapter';
import { giphyApi } from '../api/giphy.api';
import { giphySearchResponseMock } from './../../../tests/mocks/giphy.response.data';

mock = new AxiosMockAdapter(giphyApi);

test('should return a list of gifs', async () => {
  mock.onGet('/search').reply(200, giphySearchResponseMock);;

  const gifs = await getGifsByQuery('goku');

  expect(gifs.length).toBe(10);

  gifs.forEach((gif) => {
    expect(typeof gif.id).toBe('string');
    expect(typeof gif.title).toBe('string');
    expect(typeof gif.url).toBe('string');
    expect(typeof gif.width).toBe('number');
    expect(typeof gif.height).toBe('number');
  });
})
```

## 104. Excepciones en las peticiones


src\gifs\actions\get-gifs-by-query.action.test.ts
```js
  test('should return an empty list of gifs if query is empty', async () => {
    // mock.onGet('/search').reply(200, { data: [] });
    mock.restore();

    const gifs = await getGifsByQuery('');

    expect(gifs.length).toBe(0);
  });

  test('should handle error when the API returns an error', async () => {
    const consoleErrorSpy = vi
      .spyOn(console, 'error')
      .mockImplementation(() => {});

    mock.onGet('/search').reply(400, {
      data: {
        message: 'Bad Request',
      },
    });

    const gifs = await getGifsByQuery('goku');

    expect(gifs.length).toBe(0);
    expect(consoleErrorSpy).toHaveBeenCalled();
    expect(consoleErrorSpy).toHaveBeenCalledTimes(1);
    expect(consoleErrorSpy).toHaveBeenCalledWith(expect.anything());
  });
```

## 106. Pruebas sobre useGifs
src\gifs\hooks\useGifs.test.tsx


## 107. Pruebas sobre useGifs - Caché
src\gifs\hooks\useGifs.test.tsx
```js
  test('should return a list of gifs from cache', async () => {});
  test('should return no more than 8 previous terms', async () => {});

```
## 108. Pruebas sobre efectos y debounce

src\shared\components\SearchBar.test.tsx
```js
  test('should render searchbar correctly', () => {});

  test('should call onQuery with the correct value after 700ms', async () => {});

```
## 109. Pruebas adicionales sobre efectos

src\shared\components\SearchBar.test.tsx
```js
  test('should call only once with the last value (debounce)', async () => {});

  test('should call onQuery when button clicked with the input value', () => {});

```

## 110. Porcentaje de cobertura

```bash
npm run coverage
```

## 111. Integrar pruebas con la versión de producción

package.json
```js
  "scripts": {
    "build": "npm run test:only && tsc -b && vite build",
    "test:only": "vitest run",
  },
```