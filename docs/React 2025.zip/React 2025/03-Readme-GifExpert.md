# Section 6: GifExpertApp - Application
Source code: "react-ts-gifs-fin-seccion-06.zip"

* Peticiones HTTP
* Debounce
* Manejo de estado
* Comunicación entre componentes
* useEffect
* Variables de entorno
* Fuentes personalizadas

## 68. Inicio de proyecto - GifsApp
> npm create vite
project name: 03-gifs-app
select a framework: React
Select a variant: TypeScript + SWC

## 69. Estructura inicial, estilos y fuente

https://fonts.google.com/specimen/Montserrat+Alternates

index.html
```html

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:wght@300;400;700&display=swap"
      rel="stylesheet"
    />

```

index.css
```css
.montserrat-light {
  font-family: 'Montserrat Alternates', sans-serif;
  font-weight: 300;
  font-style: normal;
}

.montserrat-regular {
  font-family: 'Montserrat Alternates', sans-serif;
  font-weight: 400;
  font-style: normal;
}

.montserrat-bold {
  font-family: 'Montserrat Alternates', sans-serif;
  font-weight: 700;
  font-style: normal;
}
```

src/gifs/GifsApp.tsx
```js
import { mockGifs } from './mock-data/gifs.mock';

export const GifsApp = () => {
    
  return (
    <>
        {/* Header */}
        <div className="content-center">
            <h1>Buscador de Gifs</h1>
            <p>Descubre y comparte el gif perfecto</p>
        </div>

        {/* Search */}
        <div className="search-container">
            <input
                type="text"
                placeholder="Busca lo que quieras"
            />
            <button>Buscar</button>
        </div>

        {/* Búsquedas previas */}
        <div className="previous-searches">
            <h2>Búsquedas previas</h2>
            <ul className="previous-searches-list">
                <li>Goku</li>
                <li>Saitama</li>
                <li>Elden Ring</li>
            </ul>
        </div>

        {/* Gifs */}
        <div className="gifs-container">
            {mockGifs.map((gif) => (
                <div key={gif.id} className="gif-card">
                <img src={gif.url} alt={gif.title} />
                <h3>{gif.title}</h3>
                <p>
                    {gif.width}x{gif.height} (1.5mb)
                </p>
                </div>
            ))}
        </div>
    </>
  );
}
```
## 70. Pensemos en componentes
src/shared/components/CustomHeader.tsx
```js
interface Props {           // <-----------------
  title: string;
  description?: string;
}

export const CustomHeader = ({ title, description }: Props) => {
  return (
    <div className="content-center">
      <h1>{title}</h1>
      {description && <p>{description}</p>}
    </div>
  );
};

```

## 71. Solución a la tarea - GifList
src/gifs/components/GifList.tsx
```js
import type { FC } from 'react';
import type { Gif } from '../../mock-data/gifs.mock';

interface Props {
  gifs: Gif[];
}

// FC significa Functional Component
export const GifList: FC<Props> = ({ gifs }) => {
  return (
    <div className="gifs-container">
      {gifs.map((gif) => (
        <div key={gif.id} className="gif-card">
          <img src={gif.url} alt={gif.title} />
          <h3>{gif.title}</h3>
          <p>
            {gif.width}x{gif.height} (1.5mb)
          </p>
        </div>
      ))}
    </div>
  );
};
```

## 72. Manejo de estado - Búsquedas previas / Comunicación entre componentes
src/GifApp.tsx
```js
import { useState } from 'react';

export const GifsApp = () => {
  const [previousTerms, setPreviousTerms] = useState<string[]>([]);
  
  // Comunicación entre componentes
  const handleTermClicked = (term: string) => {
    console.log({ term });
  };

  {/* Búsquedas previas */}
    <PreviousSearches
        searches={previousTerms}
        onLabelClicked={handleTermClicked}  // Comunicación entre componentes
    />
}
```

src/gifs/components/PreviousSearches.tsx
```js
import type { FC } from 'react';

interface Props {
  searches: string[];

  onLabelClicked: (term: string) => void; // Comunicación entre componentes
}

export const PreviousSearches: FC<Props> = ({ searches, onLabelClicked }) => {
  return (
    <div className="previous-searches">
      <h2>Búsquedas previas</h2>
      <ul className="previous-searches-list">
        {searches.map((term) => (
          <li key={term} onClick={() => onLabelClicked(term)}> 
            {term}
          </li>
        ))}
      </ul>
    </div>
  );
};
```

## 73. Manejo del componente búsqueda

src/GifsApp.tsx
```js

export const GifsApp = () => {
  const [previousTerms, setPreviousTerms] = useState<string[]>([]);

  const handleSearch = async (query: string = '') => {
    query = query.trim().toLowerCase();

    if (query.length === 0) return;

    if (previousTerms.includes(query)) return;

    setPreviousTerms([query, ...previousTerms].splice(0, 8));

    const gifs = await getGifsByQuery(query);
    setGifs(gifs);
  };
  
  return (
    <>
      {/* Search */}
      <SearchBar placeholder="Busca lo que quieras" onQuery={handleSearch} />
    </>
  );
}
```

src/shared/components/SearchBar.tsx
```js
import { useState, type KeyboardEvent } from 'react';

interface Props {
  placeholder?: string;

  onQuery: (query: string) => void;
}
export const SearchBar = ({ placeholder = 'Buscar', onQuery }: Props) => {
  const [query, setQuery] = useState('');

  const handleSearch = () => {
    onQuery(query);
    // setQuery('');
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="search-container">
      <input
        type="text"
        placeholder={placeholder}
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        onKeyDown={handleKeyDown}
      />
      <button onClick={handleSearch}>Buscar</button>
    </div>
  );
}
```

## 74. useEffect - Debounce

useEffect - Ejecuta efectos secundarios y limpieza al demostrar el componente

src/shared/components/SearchBar.tsx
```js
export const SearchBar = ({ placeholder = 'Buscar', onQuery }: Props) => {
  const [query, setQuery] = useState('');

  // useEffect ----------------------
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      onQuery(query);
    }, 700);

    return () => {
      clearTimeout(timeoutId);
    };
  }, [query, onQuery]);
}
```

## 76. Developers Giphy - API Key

## 77. Obtener gifs mediante petición http
> npm install axios

src\gifs\api\giphy.api.ts
```js
import axios from 'axios';

export const giphyApi = axios.create({
  baseURL: 'https://api.giphy.com/v1/gifs',
  params: {
    lang: 'es',
    api_key: import.meta.env.VITE_GIPHY_API_KEY,
  },
});
```

src\gifs\actions\get-gifs-by-query.action.ts
```js
export const getGifsByQuery = async (query: string): Promise<Gif[]> => {
  const response = await giphyApi<GiphyResponse>('/search', {
    params: {
      q: query,
      limit: 10,
    },
  });

  return response.data.data.map((gif) => ({
    id: gif.id,
    title: gif.title,
    url: gif.images.original.url,
    width: Number(gif.images.original.width),
    height: Number(gif.images.original.height),
  }));
};
```

## 78. Variables de entorno
.env
```
VITE_GIPHY_API_KEY=ASDFNN23KD34343
```

src\gifs\api\giphy.api.ts
```js
import axios from 'axios';

export const giphyApi = axios.create({
  baseURL: 'https://api.giphy.com/v1/gifs',
  params: {
    lang: 'es',
    api_key: import.meta.env.VITE_GIPHY_API_KEY,  // <------------------
  },
});
```

# Section 7: Optimización y despliegue
Source code: "react-ts-gifs-fin-seccion-07.zip"

* Custom Hooks - Hooks personalizados
* DevTools de React
* useRef - Hook propio de React
* Generar versión de producción
* Separación de responsabilidades

## 86. Custom Hooks

src\counter\hooks\useCounter.tsx
```js
import { useState } from 'react';

export const useCounter = (initialValue: number = 10) => {
  const [counter, setCounter] = useState(initialValue);

  const handleAdd = () => {
    setCounter(counter + 1);
  };

  const handleSubtract = () => {
    setCounter((prevState) => prevState - 1);
  };

  const handleReset = () => {
    setCounter(initialValue);
  };

  return {
    // Values
    counter,

    // Methods / Actions
    handleAdd,
    handleSubtract,
    handleReset,
  };
};
```

src\counter\components\MyCounterApp.tsx
```js
import { useCounter } from '../hooks/useCounter';

export const MyCounterApp = () => {
  const { counter, handleAdd, handleReset, handleSubtract } = useCounter();

  return (
    <div
      style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}
    >
      <h1>counter: {counter}</h1>

      <div style={{ display: 'flex', gap: '10px' }}>
        <button onClick={handleAdd}>+1</button>
        <button onClick={handleSubtract}>-1</button>
        <button onClick={handleReset}>Reset</button>
      </div>
    </div>
  );
};

```

## 87. React DevTools

React Developer Tools
https://react.dev/learn/react-developer-tools

## 88. Hook Personalizado - useGifs

src\gifs\hooks\useGifs.tsx
```js
export const useGifs = () => {
  
  /* ---- */
  
  return {
    // Properties
    gifs,

    // Methods
    handleSearch,
    handleTermClicked,
    previousTerms,
  };
};
```

src\GifsApp.tsx
```js
  const { handleSearch, previousTerms, handleTermClicked, gifs } = useGifs();
```

## 89. Manejo en caché

## 90. useRef - Mantener el valor entre re-renders

* useRef
Referencias mutables que no causan re-render.

src\gifs\hooks\useGifs.tsx
```js
import { useRef, useState } from 'react';

export const useGifs = () => {

  const gifsCache = useRef<Record<string, Gif[]>>({});
}
```
## 91. Generar versión de producción

* Deploy Local
> npm run build
crea una carpeta "dist"

* Hosting, servidor estático de archivos para montar un HOST LOCAL
https://www.npmjs.com/package/http-server

> npm install --global http-server
> http-server -o

* Deploy 
Desplegar aplicaciones de Node
https://www.netlify.com/
- Crear cuenta
- Add new project