# Section 15: Context API - Búsquedas y favoritos
Source Code: "12-react-ts-heroes-app-fin-seccion-15.zip"

El objetivo es seguir el patrón de delegar la mayor cantidad de lógica a estados fuera de `useState` y `useEffect` para optimizar el rendimiento y, finalmente, preservar el estado al compartir el enlace de la aplicación.

## 209. Contexto para control de favoritos

Crear un gestor de estado

src\heroes\context\FavoriteHeroContext.tsx
```js
import { createContext } from "react";
import type { Hero } from "../types/hero.interface";

interface FavoriteHeroContext {
    // State
    favorites: Hero[];
    favoriteCount: number;

    // Methods
    isFavorite: (hero: Hero) => boolean;
    toggleFavorite: (hero: Hero) => void;
}

export const FavoriteHeroContext = createContext<FavoriteHeroContext>({} as FavoriteHeroContext);
```

Crear el componente

src\heroes\context\FavoriteHeroContext.tsx
```js

export const FavoriteHeroProvider = ({ children }: PropsWithChildren) => {

    const [favorites, setFavorites] = useState<Hero[]>([]);

    const toggleFavorite = (hero: Hero) => {
        const heroExist = favorites.find(h => h.id === hero.id);

        if (heroExist) {
            setFavorites(favorites.filter(h => h.id !== hero.id));
            return;
        }

        setFavorites([...favorites, hero]);
    }

    return (
        <FavoriteHeroContext value={{
            // State
            favorites: [],
            favoriteCount: 0,

            // Methods
            isFavorite: () => { },
            toggleFavorite: toggleFavorite

        }}>{children}</FavoriteHeroContext>
    )
}
```

## 210. Contexto de favoritos - Parte 2

Agregar el FavoriteHeroProvider dentro de HeroesApp
src\HeroesApp.tsx
```js
export const HeroesApp = () => {
    return (
        <QueryClientProvider client={queryClient}>
            <FavoriteHeroProvider>
                <RouterProvider router={appRouter} />
                <ReactQueryDevtools initialIsOpen={false} />
            </FavoriteHeroProvider>
        </QueryClientProvider>
    )
}
```

Recuperar los favoritos del LocalStorage y 
guardar favoritos en LocalStorage

src\heroes\context\FavoriteHeroContext.tsx
```js

const getFavoritesFromLocalStorage = () => {
    const favorites = localStorage.getItem('favorites');
    return favorites ? JSON.parse(favorites) : [];
}


export const FavoriteHeroProvider = ({ children }: PropsWithChildren) => {

    const [favorites, setFavorites] = useState<Hero[]>(getFavoritesFromLocalStorage());
    
    useEffect(() => {
        localStorage.setItem('favorites', JSON.stringify(favorites));
    }, [favorites])
}
```

## 211. Consumir el contexto de favoritos

Utilizar use en lugar del hook useContext

src\heroes\components\HeroGridCard.tsx
```js
    const {isFavorite, toggleFavorite} = use(FavoriteHeroContext);
```

## 212. useRef - En valores de inputs

Para un "input" cuando su valor no necesita ser mostrado en tiempo real en otra parte de la UI
En lugar de utilizar useState como: 
src\heroes\pages\search\ui\SearchControls.tsx
```js
export const SearchControls = () => {
    const [query, setQuery] = useState('');

    {/* Search */}
    <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
        <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search heroes, villains, powers, teams..." className="pl-12 h-12 text-lg bg-white" />
    </div>
}
```

Utilizar un useRef
src\heroes\pages\search\ui\SearchControls.tsx
```js
export const SearchControls = () => {
    const inputRef = useRef<HTMLInputElement>(null);
    {/* Search */}
    <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
        <Input
            ref={inputRef}
            placeholder="Search heroes, villains, powers, teams..." className="pl-12 h-12 text-lg bg-white" />
    </div>
}

```

## 213. Buscar héroes por nombre

## 215. Componentes de búsqueda adicionales

Del shadcn agregar el slider:
src\heroes\pages\search\ui\SearchControls.tsx
```js
    <div className="mt-4">
        <label className="text-sm font-medium">Minimum Strength: 0/10</label>
        <Slider defaultValue={[3]} max={10} step={1} />
    </div>
```

Del shadcn agregar el acordión:
src\heroes\pages\search\ui\SearchControls.tsx
```js
    {/* Advanced Filters */}
    <Accordion type="single" collapsible value="item-1">
        <AccordionItem value="item-1">
            {/* <AccordionTrigger>Filtros avanzados</AccordionTrigger> */}
            <AccordionContent>

            
            </AccordionContent>
        </AccordionItem>
    </Accordion>
```

## 216. Filtros avanzados