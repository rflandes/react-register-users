# Section 14: Funcionalidad, caché y optimizaciones
Source Code: "11-react-ts-heroes-app-fin-seccion-14.zip"
Source Code BE: "11-nest-heroes-backend-main.zip"

* Variables de Entorno
* TanStack Query
* QueryParameters
* Caché
* Custom Hooks especializados
* Paginaciones por categorías

## 191. Continuación del proyecto

Descargar proyecto BE: nest-heroes-backend-main
> npm install
> npm run start:dev

## 192. Axios, variables de entorno y API

Crear archivo de definición de variables de entorno
.env
```
VITE_API_URL=http://localhost:3000
```

.env.template
```
VITE_API_URL=http://localhost:3000
```

Axios
> npm install axios

Crear archivo API, y crear instancia de axios
src\heroes\api\hero.api.ts
```js
import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL;

export const heroApi = axios.create({
    baseURL: `${BASE_URL}/api/heroes`
});
```

Agregar las peticiones API
src\heroes\actions\get-heroes-by-page.action.ts
```js
import { heroApi } from "../api/hero.api";

export const getHeroesByPage = async () => {
    const { data } = await heroApi.get(`/`);
    return data;
};
```
LLamar a la petición 
(!! Inconveniente, cada vez que se muestra la pantalla Home, se vuelve a hacer la petición API) 
src\heroes\pages\home\HomePage.tsx
```js
  useEffect(() => {
    getHeroesByPage().then((heroes) => {
      console.log({ heroes });
    })

  }, [])
```

## 193. TanStack Query - Gestor de estado asíncrono

TanStack Query - Gestor de estado asíncrono
Install
> npm i @tanstack/react-query
> npm i -D @tanstack/eslint-plugin-query

Crear un query client 
https://tanstack.com/query/latest/docs/framework/react/quick-start

src\HeroesApp.tsx
```js
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

// Create a client
const queryClient = new QueryClient()

export const HeroesApp = () => {
    return (
        <QueryClientProvider client={queryClient}>
            <RouterProvider router={appRouter} />
        </QueryClientProvider>
    )
}

```

Instalar las devtools
https://tanstack.com/query/latest/docs/framework/react/devtools

>npm i @tanstack/react-query-devtools

Agregar las devtools
src\HeroesApp.tsx
```js
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'

// Create a client
const queryClient = new QueryClient()

export const HeroesApp = () => {
    return (
        <QueryClientProvider client={queryClient}>
            <RouterProvider router={appRouter} />
            <ReactQueryDevtools initialIsOpen={false} />
        </QueryClientProvider>
    )
}
```

En el browser aparecerá un icono de una palmera, ese es el DevTools
src\heroes\pages\home\HomePage.tsx
```js

  // useEffect(() => {
  //   getHeroesByPageAction().then((heroes) => {
  //     console.log({ heroes });
  //   })

  // }, [])

  const { data } = useQuery({
    queryKey: ['heroes'],
    queryFn: () => getHeroesByPageAction(),
    staleTime: 1000 * 60 * 5 // 5 minutos, cuanto tiempo mantiene la data (cache)
  });
```

## 194. Tipado estricto de la data

Hacer el proceso de tipado
src\heroes\types\hero.interface.ts
src\heroes\types\get-heroes.response.ts
src\heroes\actions\get-heroes-by-page.action.ts
```js

export const getHeroesByPageAction = async (): Promise<HeroesResponse> => {
    const { data } = await heroApi.get<HeroesResponse>(`/`);
    console.log({ data })
    return data;
};
```

Mapear la data

src\heroes\actions\get-heroes-by-page.action.ts
```js
const BASE_URL = import.meta.env.VITE_API_URL;

export const getHeroesByPageAction = async (): Promise<HeroesResponse> => {
    const { data } = await heroApi.get<HeroesResponse>(`/`);

    const heroes = data.heroes.map(hero => ({
        ...hero,
        image: `${BASE_URL}/images/${hero.image}`
    }));

    return {
        ...data,
        heroes: heroes
    };
};
```
## 195. Mostrar la data de los héroes
Tarea

## 196. Navegación manual dentro de las tarjetas

src\heroes\components\HeroGridCard.tsx

```js
    const navigate = useNavigate();

    const handleClick = () => {
        navigate(`/heroes/${heroe.slug}`);
    }

```

src\router\app.router.tsx
```js
    {
        path: 'heroes/:idSlug',
        element: <HeroPage />
    },
```

src\heroes\pages\hero\HeroPage.tsx
```js
import { useParams } from "react-router"

export const HeroPage = () => {
    const { idSlug = '' } = useParams();

    return (
        <div>HeroPage</div>
    )
}
```
## 197. QueryParameters sobre useState

Utilizar queryParams en lugar de useEffect()
src\heroes\pages\home\HomePage.tsx
```js

  const activeTab = searchParams.get('tab') ?? 'all';

  // const [activeTab, setActiveTab] = useState<'all' |
  //   'favorites' |
  //   'heroes' |
  //   'villains'>('all');

            <TabsTrigger value="all" onClick={() => setSearchParams('?tab=all')}>All Characters (16)</TabsTrigger>

```

improvement at setSearchParams
src\heroes\pages\home\HomePage.tsx
```js
            <TabsTrigger value="all" onClick={() => {
              setSearchParams((prev) => {
                prev.set('tab', 'all');
                return prev
              })
            }}
            >All Characters (16)</TabsTrigger>

```

Validar queryParams
src\heroes\pages\home\HomePage.tsx
```js
    const activeTab = searchParams.get('tab') ?? 'all';
    const selectedTab = useMemo(() => {
        const validTabs = ['all', 'favorites', 'heroes', 'villains']
        return validTabs.includes(activeTab) ? activeTab : 'all';
    }, [activeTab]);

    {/* Tabs */}
        <Tabs value={selectedTab} className="mb-8">
        </Tabs>
```

## 198. Paginar datos

Pasar la pagina y el limite
src\heroes\actions\get-heroes-by-page.action.ts
```js
export const getHeroesByPageAction = async (
    page: number, limit: number = 6
): Promise<HeroesResponse> => {
    if (isNaN(page)) {
        page = 1;
    }
    const { data } = await heroApi.get<HeroesResponse>(`/`, {
        params: {
            limit: limit,
            offset: limit * (page - 1)
        }
    });

```

## 199. Componente de paginación
src\heroes\pages\home\HomePage.tsx

```js
  const page = searchParams.get('page') ?? '1';
  const limit = searchParams.get('limit') ?? '6';

  const { data: heroesResponse } = useQuery({
    queryKey: ['heroes', { page: page, limit: limit }],
    queryFn: () => getHeroesByPageAction(+page, +limit),
    staleTime: 1000 * 60 * 5 // 5 minutos, cuanto tiempo mantiene la data (cache)
  });
```

src\components\custom\CustomPagination.tsx
```js

    const [searchParams, setSearchParams] = useSearchParams();

    const queryPage = searchParams.get('page') ?? '1';
    const page = isNaN(+queryPage) ? 1 : +queryPage;
```

## 200. Mostar resumen estadistico

src\heroes\actions\get-summary.action.ts
```js
export const getSummaryAction = async () => {
    const { data } = await heroApi.get<SummaryInformationResponse>('/summary');
    return data;
}
```

utilizar el useQuery 
src\heroes\components\HeroStats.tsx
```js
    const { data: summary } = useQuery({
        queryKey: ['summary-information'],
        queryFn: () => getSummaryAction(),
        staleTime: 1000 * 60 * 5, // 5 minutos
    })
```

## 201. CustomHook - useSummary + solución de tarea

Crear custom hook y pasar el useQuery

src\heroes\hooks\useHeroSummary.tsx
```js
import { useQuery } from "@tanstack/react-query";
import { getSummaryAction } from "../actions/get-summary.action";

export const useHeroSummary = () => {
    return useQuery({
        queryKey: ['summary-information'],
        queryFn: () => getSummaryAction(),
        staleTime: 1000 * 60 * 5, // 5 minutos
    });
}

```

Utilizar el customHook useHeroSummary
src\heroes\pages\home\HomePage.tsx
```js

  // const { data: summary } = useQuery({
  //   queryKey: ['summary-information'],
  //   queryFn: () => getSummaryAction(),
  //   staleTime: 1000 * 60 * 5, // 5 minutos
  // });

  const { data: summary } = useHeroSummary();
```

## 202. Paginar por categoría

src\heroes\pages\home\HomePage.tsx
```js

  const category = searchParams.get('category') ?? 'all';

  const selectedTab = useMemo(() => {
    const validTabs = ['all', 'favorites', 'heroes', 'villains']

    return validTabs.includes(activeTab) ? activeTab : 'all';
  }, [activeTab])

  
            <TabsTrigger value="all" onClick={() => {
              setSearchParams((prev) => {
                prev.set('tab', 'all');
                prev.set('category', 'all');
                prev.set('page', '1');
                return prev
              })
            }}
            >All Characters ({summary?.totalHeroes})</TabsTrigger>
```

## 203. Página de Héroe
