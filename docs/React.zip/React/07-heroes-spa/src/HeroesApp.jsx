
export const HeroesApp = () => {
    return (
        <>
            <h1>HeroesApp</h1>
        </>
    )
}
