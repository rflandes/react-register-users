import { createBrowserRouter, Navigate } from "react-router-dom";

import { LoginPage } from "../auth";
import { NavbarWrapper } from "../ui";
import { HeroesRoutes } from "../heroes";

export const AppRouter = createBrowserRouter([
  {
    path: "login",
    element: <LoginPage />
  },
  {
    path: '/',
    element: <NavbarWrapper />,
    children: [
      ...HeroesRoutes,
    ]
  },
  {
    path: '/*',
    element: <Navigate to="/" />
  }
]);

