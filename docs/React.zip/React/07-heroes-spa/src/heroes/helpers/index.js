export * from './getHeroById';
export * from './getHerosByPublisher';
export * from './getHerosByName';