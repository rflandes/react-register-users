export * from './DcPage';
export * from './MarvelPage';
export * from './SearchPage';
export * from './HeroPage';