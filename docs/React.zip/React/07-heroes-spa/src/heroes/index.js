export * from './pages/DcPage'
export * from './pages/MarvelPage'
export * from './routes/HeroesRoutes'