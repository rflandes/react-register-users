import PropTypes from 'prop-types'

const newMessage = {
    message: 'Chanchito Feliz',
    title: 'Curso React'
}

const getSaludo = () => {
    return 'Este es mi saludo';
}

// export const FirstApp = (props) => {
export const FirstApp = ({ title, subTitle }) => {



    return (
        <>
            {/* <h1>{props.title}</h1> */}
            <h1>{title}</h1>
            <h4>{subTitle}</h4>
            {/* <h1>{newMessage.title}</h1>
            <h1>{getSaludo()}</h1>
            <code>{JSON.stringify(newMessage)}</code>
            <p>Soy un subtitulo</p> */}
        </>
    );
}

FirstApp.propTypes = {
    title: PropTypes.string.isRequired,
    subTitle: PropTypes.number.isRequired
}

FirstApp.defaultProps = {
    title: 'Sin Título',
    subTitle: 456
}