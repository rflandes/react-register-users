import { act, renderHook } from "@testing-library/react";
import { useForm } from "../../src/hooks/useForm";


describe('Pruebas en el useForm', () => {

    test('debe de regresar la información por defecto', () => {

        const initialForm = {
            username: 'Roberto',
            email: 'rob@mail.com'
        }

        const { result } = renderHook(() => useForm(initialForm));

        // console.log(result);
        expect(result.current).toEqual({
            username: initialForm.username,
            email: initialForm.email,
            formState: initialForm,
            onInputChange: expect.any(Function),
            onResetForm: expect.any(Function)
        });
    });

    test('debe de cambiar el nombre del formulario', () => {

        const initialForm = {
            username: 'Roberto',
            email: 'rob@mail.com'
        }

        const target = {
            name: 'username', value: 'Carlos'
        }

        const { result } = renderHook(() => useForm(initialForm));

        act(() => {
            result.current.onInputChange({ target });
        });

        expect(result.current.username).toBe(target.value);
        expect(result.current.formState.username).toBe(target.value);

    });

    test('debe de realizar el reset del formulario', () => {

        const initialForm = {
            username: 'Roberto',
            email: 'rob@mail.com'
        }

        const target = {
            name: 'username', value: 'Carlos'
        }

        const { result } = renderHook(() => useForm(initialForm));

        act(() => {
            result.current.onInputChange({ target });
            result.current.onResetForm();
        });

        expect(result.current.username).toBe(initialForm.username);
        expect(result.current.email).toBe(initialForm.email);
        expect(result.current.formState.username).toBe(initialForm.username);
        expect(result.current.formState.email).toBe(initialForm.email);

    });

});