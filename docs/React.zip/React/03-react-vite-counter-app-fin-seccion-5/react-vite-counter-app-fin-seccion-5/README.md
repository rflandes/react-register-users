# React + Vite: CounterApp

1. Clonar o instalar
2. Ejecutar el comando:
```
yarn install
```

3. Correr la aplicación
```
yarn dev
```
