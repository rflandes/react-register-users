

export const retornaArreglo = () =>{
    return ['ABC', 123];
}





