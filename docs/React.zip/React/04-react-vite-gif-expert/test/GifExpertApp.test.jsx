import { fireEvent, render, screen } from '@testing-library/react';
import { GifExpertApp } from '../src/GifExpertApp';

describe('Pruebas en <GifExpertApp />', () => {

    test('debe de cambiar el valor de la caja de text', () => {

        const inputValue = 'Saitama';
        render(<GifExpertApp onNewCategory={() => { }} />);

        // screen.debug();
    });

});