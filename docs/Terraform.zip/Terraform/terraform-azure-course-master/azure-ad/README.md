# Setup CosmosDB

# Sign in
```
az login
```

# Run Terraform init
```
terraform init
```

# Run Terraform apply
```
terraform apply
```
