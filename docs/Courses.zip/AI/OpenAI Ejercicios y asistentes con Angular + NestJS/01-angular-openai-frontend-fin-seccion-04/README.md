# AngularGpt

Pasos para ejecutar en dev

1. Instalar dependencias con `npm install`
2. Ejecutar `ng serve` para levantar el servidor de desarrollo.
3. Navegar a `http://localhost:4200/`
