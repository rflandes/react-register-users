export const environment = {
  backendApi: 'http://localhost:3000/gpt',
  assistantApi: 'http://localhost:3000/sam-assistant',
};
