

export interface Message {
  text: string;
  isGpt: boolean;
}
