

export * from './message.interface';
