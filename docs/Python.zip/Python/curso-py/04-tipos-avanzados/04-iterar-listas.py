

print()

mascotas = ["Pelusa", "Pulga", "Felipe", "Chanchito feliz"]

for mascota in enumerate(mascotas):
    # enumerate returns a tuple
    print(mascota[0], mascota[1])

print()

for indice, mascota in enumerate(mascotas):
    # enumerate returns a tuple
    print(indice, mascota)

print()
