
print()

numeros = (1, 2, 3)
print(numeros)

numeros = (1, 2, 3) + (4, 5, 6)
print(numeros)

print()

punto = tuple([1, 2])
print(punto)

menos_numeros = numeros[:2]
print(menos_numeros)

print()

primero, segundo, *otros = numeros
print(primero, segundo, otros)

print()
