"""DICCIONARIO"""

print()

punto = {"x": 25, "y": 50}
print(punto)
print()

print(punto["x"])
print()

punto["z"] = 45
print(punto)
print()


if "w" in punto:
    print("w esta en el diccionario con el valor", punto["w"])
    print()

print("valor de x", punto.get("x"))
print("valor de w", punto.get("w"))
print("valor de w", punto.get("w", 97))
print()

del punto["x"]
print(punto)
del (punto["y"])
print(punto)
print()

punto["x"] = 25

for valor in punto:
    print(valor, punto[valor])
print()

for valor in punto.items():
    print("Items", valor)
print()

print("Llave-valor")
for llave, valor in punto.items():
    print(llave, valor)
print()

print("Usuarios:")
usuarios = [
    {"id": 1, "nombre": "Usuario 1"},
    {"id": 2, "nombre": "Usuario 2"},
    {"id": 3, "nombre": "Usuario 3"},
    {"id": 4, "nombre": "Usuario 4"},
]

for usuario in usuarios:
    print(usuario["nombre"])

print()
