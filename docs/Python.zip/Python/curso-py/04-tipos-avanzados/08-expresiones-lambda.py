
print()

usuarios = [
    ["Chanchito", 4],
    ["Felipe", 2],
    ["Pulga", 5],
]

usuarios.sort(key=lambda el: el[1])
print(usuarios)

print()
