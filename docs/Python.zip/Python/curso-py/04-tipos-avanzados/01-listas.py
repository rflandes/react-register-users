
numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["perro", "gato"]
booleans = [True, False, False, True]
matriz = [[0, 1], [1, 0]]

ceros = [0] * 10

print()

print("ceros:", ceros)
ceros = [0, 1] * 10
print("ceros y unos:", ceros)

print()

alfanumerico = numeros + letras

print("alfanumerico:", alfanumerico)

print()

rango = list(range(10))
print("rango", rango)

rango = list(range(1, 11))
print("rango", rango)

print()

chars = list("hola mundo")
print("chars", chars)

print()
