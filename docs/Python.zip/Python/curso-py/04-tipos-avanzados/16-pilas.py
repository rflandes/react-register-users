

print()

pila = []
pila.append(1)
pila.append(3)
pila.append(4)
print(pila)
print()

ultimo_elemento = pila.pop()
print("ultimo_elemento", ultimo_elemento)
print("pila", pila)
print()

print("ultimo elmento", pila[-1])
print()

pila.pop()
pila.pop()
if not pila:
    print("Pila vacia")
    print()

print()
print()
