
print()

primer = {1, 1, 2, 2, 3, 4}

print(primer)

primer.add(5)
primer.remove(1)
print(primer)
print()

segundo = [3, 4, 5]
segundo = set(segundo)
print(segundo)
print()

primer = {1, 2, 3, 4}
# |: union
print("|: union")
print(primer | segundo)
print()

# &: interseccion
print("&: interseccion")
print(primer & segundo)
print()


# -: diferencia
print("-: diferencia")
print(primer - segundo)
print()


# ^: diferencia simetrica
print("^: diferencia simetrica")
print(primer ^ segundo)
print()

if 5 in segundo:
    print("5 se encuentra en ", segundo)
print()
