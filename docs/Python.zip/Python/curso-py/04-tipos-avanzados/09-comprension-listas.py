
print()


usuarios = [
    ["Chanchito", 4],
    ["Felipe", 1],
    ["Pulga", 5],
]

print(usuarios)

nombres = []

for usuario in usuarios:
    nombres.append(usuario[0])

print(nombres)
print()

# nombres = [expresion for item in items]
# map
nombres = [usuario[0] for usuario in usuarios]
print(nombres)


# filtrar
# filter
# nombres = [usuario for usuario in usuarios if usuario[1] > 2]
nombres = [usuario[0] for usuario in usuarios if usuario[1] > 2]
print(nombres)

print()
