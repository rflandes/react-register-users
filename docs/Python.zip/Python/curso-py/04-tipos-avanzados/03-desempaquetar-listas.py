

print()

numeros = [1, 2, 3]

primero, segundo, tercero = numeros

print(primero)
print(segundo)
print(tercero)

print()

primero, *otros = numeros

print(primero, otros)

print()

numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9]
primero, *otros, ultimo = numeros
print(primero, otros, ultimo)

print()
