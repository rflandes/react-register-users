
print()

numeros = [2, 5, 3, 7, 6, 9]

print(numeros)
# numeros.sort()
numeros.sort(reverse=True)
print(numeros)

print()

# nueva_lista = sorted(numeros)
nueva_lista = sorted(numeros, reverse=True)
print(nueva_lista)

print()

usuarios = [
    [4, "Chanchito"],
    [2, "Felipe"],
    [5, "Pulga"],
]

usuarios.sort()
print(usuarios)


usuarios = [
    ["Chanchito", 4],
    ["Felipe", 2],
    ["Pulga", 5],
]


def ordena(elemento):
    return elemento[1]


usuarios.sort(key=ordena)
print(usuarios)

print()
