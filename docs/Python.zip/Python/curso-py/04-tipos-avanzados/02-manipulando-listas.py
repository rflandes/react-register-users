
mascotas = ["Wolfgang", "Pelusa", "Pulga", "Copito"]

print()

print("mascotas:", mascotas)
print("Segunda Mascota:", mascotas[1])

mascotas[0] = "Sally"
print("mascotas:", mascotas)

print()

print("mascotas primeros 3 elementos:", mascotas[0:3])
print("mascotas primeros 3 elementos:", mascotas[:3])
print("mascotas a partir del 3 elemento:", mascotas[2:])
print("mascotas pares:", mascotas[::2])
print("mascotas impares:", mascotas[1::2])


print()

numeros = list(range(21))
print("numeros", numeros)
print("numeros pares", numeros[::2])
print("numeros impares", numeros[1::2])

print()
