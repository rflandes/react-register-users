
print()


usuarios = [
    ["Chanchito", 4],
    ["Felipe", 1],
    ["Pulga", 5],
]

print(usuarios)

nombres = []

for usuario in usuarios:
    nombres.append(usuario[0])

print(nombres)
print()

# nombres = [expresion for item in items]
# map
nombres = [usuario[0] for usuario in usuarios]
print(nombres)


# filtrar
# filter
# nombres = [usuario for usuario in usuarios if usuario[1] > 2]
# nombres = [usuario[0] for usuario in usuarios if usuario[1] > 2]

nombres = list(map(lambda usuario: usuario[0], usuarios))

print(nombres)
print()

menosUsuarios = list(filter(lambda usuario: usuario[1] > 2, usuarios))
print(menosUsuarios)


print()
