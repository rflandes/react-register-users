
print()

mascotas = [
    "Pelusa",
    "Pulga",
    "Felipe",
    "Pulga",
    "Chanchito feliz"
]

print(mascotas)
mascotas.insert(1, "Sally")
print()
print(mascotas)

mascotas.append("Ricky")
print(mascotas)

mascotas.remove("Pulga")
print(mascotas)

mascotas.pop()
print(mascotas)

mascotas.pop(1)
print(mascotas)

del mascotas[0]
print(mascotas)

mascotas.reverse()
print(mascotas)

mascotas.clear()
print(mascotas)

print()
