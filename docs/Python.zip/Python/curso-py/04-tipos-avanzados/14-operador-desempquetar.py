
print()

lista = [1, 2, 3, 4]
print(lista)
print(*lista)
print()


lista_tupla = (1, 2, 3, 4)
print(lista_tupla)
print(*lista_tupla)
print()

lista1 = [1, 2, 3, 4]
lista2 = [5, 6]
combinada = ["Agrega", *lista1, "elemento", *lista2]
print("combinada", combinada)
print()

punto1 = {"x": 19}
punto2 = {"y": 25}
nuevo_punto = {**punto1, **punto2}
print("desempaquetado con diccionario:", nuevo_punto)
print()


print()
print()
