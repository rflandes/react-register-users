

print()

mascotas = ["Pelusa", "Pulga", "Felipe", "Chanchito feliz"]

print(mascotas.index("Pulga"))
# print(mascotas.index("Sally"))
# throws an error
if "Sally" in mascotas:
    print(mascotas.index("Sally"))

print()

mascotas = ["Pelusa", "Pulga", "Felipe", "Pulga", "Chanchito feliz"]
print(mascotas.count("Pulga"))

print()
