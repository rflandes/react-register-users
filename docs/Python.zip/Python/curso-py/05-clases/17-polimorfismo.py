
from abc import ABC, abstractmethod


class Model(ABC):
    @abstractmethod
    def guardar(self):
        pass


class Usuario(Model):
    def guardar(self):
        print("guardando en DB")


class Sesion(Model):
    def guardar(self):
        print("Guardando en Archivo")


# def guardar(entidad):
#     entidad.guardar()
def guardar(entidades):
    for entidad in entidades:
        entidad.guardar()


print()

usuario = Usuario()
# guardar(usuario)

print()

sesion = Sesion()
# guardar(sesion)

print()
guardar([sesion, usuario])

print()
print()
