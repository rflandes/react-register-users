
print()

mensaje = "Hola mundo"

print("tipo de dato", type(mensaje))

print()
