
class Perro:
    def __init__(self, nombre, edad):
        self.__nombre = nombre  # Propiedad privada
        self.edad = edad

    def get_nombre(self):
        return self.__nombre

    def set_nombre(self, nombre):
        self.__nombre = nombre

    def habla(self):
        print(f"{self.__nombre} dice: Guau!")

    @classmethod
    def factory(cls):
        # FACTORY METHOD
        # return Perro("Chanchito Feliz", 4)
        return cls("Chanchito Feliz", 4)


print()

perro1 = Perro.factory()
perro1.habla()
print()

print(perro1.get_nombre())
print()

print(perro1.__dict__)
# Diccionario que contiene
# todas las propiedades de la instancia de un objeto
print(perro1._Perro__nombre)


print()
print()
