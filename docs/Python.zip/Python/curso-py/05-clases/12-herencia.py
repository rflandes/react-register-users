
class Animal:
    def comer(self):
        print("comiendo")


class Perro(Animal):
    def pasear(self):
        print("paseando")


class Chanchito(Perro):
    def programar(self):
        print("programando")


print()

perro = Perro()
perro.comer()

chanchito = Chanchito()
chanchito.programar()
chanchito.pasear()

print()
print()
print()
