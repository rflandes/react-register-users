
class Perro:
    def __init__(self, nombre):
        # self.set_nombre(nombre)
        self.nombre = nombre

    # def get_nombre(self):
    #     return self.__nombre
    @property
    # property solo se utiliza con las funciones getter
    def nombre(self):
        return self.__nombre

    # def set_nombre(self, nombre):
    #     if nombre.strip():
    #         self.__nombre = nombre
    #     return
    @nombre.setter
    def nombre(self, nombre):
        if nombre.strip():
            self.__nombre = nombre
        return


print()

perro = Perro("Choclo")
print(perro.nombre)
print()

print()
print()
print()
