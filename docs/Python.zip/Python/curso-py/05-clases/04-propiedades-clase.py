
class Perro:
    patas = 4

    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    def habla(self):
        print(f"{self.nombre} dice: Guau!")


print()

mi_perro = Perro("sally", 3)
print("Patas:", Perro.patas)

Perro.patas = 3
print("Patas de Perro:", Perro.patas)
print(f"Patas de {mi_perro.nombre}:", mi_perro.patas)

print()

mi_perro.patas = 5
print("Patas de Perro:", Perro.patas)
print(f"Patas de {mi_perro.nombre}:", mi_perro.patas)


print()
