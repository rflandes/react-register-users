

class Usuario():
    def guardar(self):
        print("guardando en DB")


class Sesion():
    def guardar(self):
        print("Guardando en Archivo")


def guardar(entidades):
    for entidad in entidades:
        entidad.guardar()


print()

usuario = Usuario()

print()

sesion = Sesion()

print()
guardar([sesion, usuario])

print()
print()
