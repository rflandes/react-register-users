
class Perro:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    def habla(self):
        print(f"{self.nombre} dice: Guau!")


print()

mi_perro = Perro("sally", 3)
print(mi_perro.nombre)
mi_perro.habla()

print()
