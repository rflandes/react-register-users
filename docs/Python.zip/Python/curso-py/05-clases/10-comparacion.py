
class Coordenadas:
    def __init__(self, lat, lon):
        self.lat = lat
        self.lon = lon

    def __eq__(self, otro):
        return self.lat == otro.lat and self.lon == otro.lon

    # def __ne__(self, otro):
    #     return self.lat != otro.lat or self.lon != otro.lon

    def __lt__(self, otro):
        # less than
        return self.lat + otro.lon < self.lon + otro.lon

    def __le__(self, otro):
        # less or equal
        return self.lat + otro.lon <= self.lon + otro.lon


print()

coords = Coordenadas(45, 27)
coords2 = Coordenadas(45, 27)

print("Equals", coords == coords2)
print(coords)
print(coords2)
print()

print("Not Equals", coords != coords2)
print()


print("Less than", coords < coords2)
print()

print("Less or equals", coords < coords2)
print()

print()
