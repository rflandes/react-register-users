
class Animal:
    def comer(self):
        print("comiendo")

    def pasear(self):
        print("paseando animales")


class Perro:
    def pasear(self):
        print("paseando perros")


class Chanchito(Animal, Perro):
    def programar(self):
        print("programando")


print()

perro = Perro()
# perro.comer()

chanchito = Chanchito()
chanchito.programar()
chanchito.pasear()
chanchito.comer()

print()
print()
print()
