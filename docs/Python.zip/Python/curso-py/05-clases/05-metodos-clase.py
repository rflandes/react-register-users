
class Perro:
    patas = 4

    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    @classmethod
    def habla(cls):
        print("Guau!")

    @classmethod
    def factory(cls):
        # FACTORY METHOD
        # return Perro("Chanchito Feliz", 4)
        return cls("Chanchito Feliz", 4)


print()

Perro.habla()
perro1 = Perro("Chanchito", 2)
perro2 = Perro("Felipe", 2)
perro3 = Perro.factory()

print(perro3.edad, perro3.nombre)
print()
print()
print()
