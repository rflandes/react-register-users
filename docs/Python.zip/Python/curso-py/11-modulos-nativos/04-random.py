

import random
import string

lista = [1, 2, 3, 4, 5, 6, 7, 8]
random.shuffle(lista)

lista2 = [1, 2, 3, 4, 5, 6, 7, 8]

print(
    random.random(),
    random.randint(1, 10),
    lista,  # random.shuffle()
    random.choice(lista2),
    random.choices(lista2, k=3),
    # util para generar contraseñas
    random.choices("lista2", k=8),
    # util para generar contraseñas
    "".join(random.choices("abcdefghaijk0123456789.,#%$", k=8)),
)

chars = string.ascii_letters
digitos = string.digits

seleccion = random.choices(chars + digitos, k=16)
print("".join(seleccion))
