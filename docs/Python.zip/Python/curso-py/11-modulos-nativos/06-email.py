
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib

mensaje = MIMEMultipart()
mensaje["from"] = "Hola Mundo"
mensaje["to"] = "ultimatepython@holamundo.io"
mensaje["subject"] = "Esta es una prueba"

body = MIMEText("Cuerpo del mensaje")
mensaje.attach(body)

with smtplib.SMTP(host="smtp.gmail.com", port="587") as smtp:
    smtp.ehlo()
    smtp.starttls()

    # smtp.login("user@holamundo-test.io", "holamundo123")
    # smtp.send_message(mensaje)
    print("Mensaje enviado! ")
