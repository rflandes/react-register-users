

import webbrowser

print("producto encontrado!")
webbrowser.open("https://academia.holamundo.io")
