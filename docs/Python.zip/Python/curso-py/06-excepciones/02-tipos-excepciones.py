
print()
try:
    n1 = int(input("Ingresa primer numero: "))
except ValueError as ex:
    print("Ingrese un valor que corresponda")

print()
print()
print()
