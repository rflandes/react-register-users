
print()

try:
    n1 = int(input("Ingresa primer numero: "))
except Exception as ex:
    print("Ingrese un valor que corresponda")
else:
    print("No ocurrió ningún error")
finally:
    print("Se ejecuta siempre")

print()
print()
print()
