
print()
try:
    n1 = int(input("Ingresa primer numero: "))
except:
    print("Ocurrió un error...")

print()
print()
print()
