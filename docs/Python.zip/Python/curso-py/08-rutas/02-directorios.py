
from pathlib import Path

path = Path("08-rutas")
# path.exists()
# path.mkdir()
# path.rmdir()
# path.rename("chanchito-feliz")

print()
print(path.iterdir())

print()
for p in path.iterdir():
    print(p)

print()
archivos = [p for p in path.iterdir() if not p.is_dir()]
for archivo in archivos:
    print(archivo)
print(archivos)

print()

archivos = [p for p in path.glob("**/*.py")]
archivos = [p for p in path.rglob("*.py")]
archivos = [p for p in path.glob("*dir*.py")]
for archivo in archivos:
    print(archivo)

print()
print()
