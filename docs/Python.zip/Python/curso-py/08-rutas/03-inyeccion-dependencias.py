

# class Perro:
#     def __init__(self, Correa):
#         self.correa = Correa()

###################################

# import usuario

# def guardar():
#     usuario.guardar()


# def guardar(entidad):
#     entidad.guardar()


###################################

# def init_app(bd, api):
#     # inicialización de módulo

###################################

from pathlib import Path

# import db
# import graphql
# import api

path = Path()
paths = [p for p in path.iterdir() if p.is_dir()]

dependencias = {
    "db": "base de datos",
    "api": "Esta es la api",
    "graphql": "Esto es graphql"
}


# dependencias = {
#     "db": db,
#     "api": api,
#     "graphql": graphql
# }

def load(p):
    # print(str(p).replace("/", "."))
    paquete = __import__(str(p).replace("/", "."))
    try:
        paquete.init(**dependencias)
    except:
        print("El paquete no tiene funcion init()")


print()
print()
# map(load, paths)
list(map(load, paths))

print()
print()
print()
