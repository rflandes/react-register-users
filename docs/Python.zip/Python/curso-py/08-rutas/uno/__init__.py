
# def init(db, api, **otros):
def init(graphql, **_):
    print(f"Soy módulo uno: {graphql}", )
