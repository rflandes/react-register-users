
def init(db, api, **_):
    print(f"Soy módulo dos: {db} - {api}")
