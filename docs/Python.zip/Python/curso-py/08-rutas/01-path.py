from pathlib import Path

# Path(r"C:\Archivos de Programa\Minecraft")

path = Path("hola-mundo/mi-archivo.py")
path.is_file()
path.is_dir()
path.exists()

print()

print(
    path.name,
    path.stem,
    path.suffix,
    path.parent,
    path.absolute(),
)

print()

print(path.name)

p = path.with_name("chanchito.py")
print(p)

p = path.with_suffix(".bat")
print(p)

p = path.with_stem("feliz")
print(p)

print()
print()
