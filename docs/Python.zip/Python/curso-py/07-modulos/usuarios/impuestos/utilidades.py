
from ..gestion.crud import guardar


def pagar_impuestos():
    print("Pagando impuestos...")
    guardar()
