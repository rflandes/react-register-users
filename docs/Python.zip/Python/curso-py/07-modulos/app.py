# from usuarios import acciones

# acciones.guardar()
# acciones.pagar_impuestos()


# Otro ejercicio
# from usuarios.acciones import guardar, pagar_impuestos

# guardar()
# pagar_impuestos()


# Otro ejercicio
# from usuarios.acciones.utilidades import guardar, pagar_impuestos

# guardar()
# pagar_impuestos()

# Otro ejercicio
# from usuarios.impuestos.utilidades import pagar_impuestos

# pagar_impuestos()


# Otro ejercicio
from usuarios.impuestos.utilidades import pagar_impuestos
import usuarios

print()

print(dir(usuarios))
print()

print(usuarios.__name__)
print(usuarios.__package__)
print(usuarios.__path__)
print(usuarios.__file__)


print()
print()
