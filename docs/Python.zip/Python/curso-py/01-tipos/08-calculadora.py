n1 = input("Ingresa primer numero: ")
n2 = input("Ingresa segundo numero: ")

print(n1, n2)
print(n1 + n2)

n1 = int(n1)
n2 = int(n2)
print(n1 + n2)

suma = n1 + n2
resta = n1 - n2
mult = n1 * n2
div = n1 / n2

mensaje = f"""
Para los números {n1} y {n2}
el resultado de la suma es {suma}
"""

print(mensaje)
