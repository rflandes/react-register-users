print()
print("Métodos de string")

animal = "chanCHito feliz"

print()
print("upper")
print(animal.upper())

print()
print("lower")
print(animal.lower())


print()
print("capitalize")
print(animal.capitalize())

print()
print("title")
print(animal.title())

animal2 = "  chanchito feliz   "
print()
print("strip 'Remueve espacios en blanco a la izquierda y a la deracha'")
print(animal2.strip())

print()
print("strip 'Remueve espacios en blanco a la izquierda y a la deracha'")
print("similares: lstrip | rstrip")
print(animal2.strip())

print()
print("find")
print(animal.find("CH"))

print()
print("replace")
print(animal.replace("CH", "j"))

print()
print("in | not in")
print("CH" in animal)
print("CH" not in animal)
