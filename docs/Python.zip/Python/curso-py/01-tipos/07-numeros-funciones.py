import math  # math.py

print()
print("Numeros funciones")

print()
print("round(1.3)", round(1.3))
print("round(1.7)", round(1.7))

print()
print("abs(-77)", abs(-77))
print("abs(77)", abs(77))

print()
print("math.ceil(1.1)", math.ceil(1.1))
print("math.floor(1.999)", math.floor(1.999))
print("math.isnan(23)", math.isnan(23))
# print("math.isnan(\"23\")", math.isnan("23"))
print("math.pow(10, 3)", math.pow(10, 3))
print("math.sqrt(9)", math.sqrt(9))

# documentacion libreria math
# https://docs.python.org/3/library/math.html
