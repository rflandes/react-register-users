"""Introduccion a Python."""

NOMBRE_CURSO = "Ultimate Python"
nombre_curso = "Ultimate Python"
NombreCurso = "Ultimate Python"
print(NOMBRE_CURSO, nombre_curso, NombreCurso)

alumnos = 5000

puntage = 9.9

PUBLICADO = True
