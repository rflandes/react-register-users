nombre = "Rob"
apellido = "Toledo"
nombre_completo = nombre + " " + apellido

print("Concatenacion")
print(nombre_completo)

print()
print("Concatenacion con formateo de expresiones")
nombre_completo2 = f"{nombre} {apellido} "
print(nombre_completo2)
