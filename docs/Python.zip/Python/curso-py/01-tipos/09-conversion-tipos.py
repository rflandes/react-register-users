# x = input("")

# int()
# str()
# float()
# bool()

print("bool()")
print(bool(""))
print(bool("0"))
print(bool(None))
print(bool(" "))
print(bool(0))
