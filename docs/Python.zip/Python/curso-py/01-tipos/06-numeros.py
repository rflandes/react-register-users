print()
print("Numeros")

print()
numero = 2  # entero - integer
decimal = 1.2  # float
imaginario = 2 + 2j  # 2 + 2i

print("numero =", numero)
numero = numero + 2
print("numero = numero + 2 =", numero)

numero += 2
print("numero += 2 =", numero)

print("Operaciones matemáticas")
print("1 + 3 =", 1 + 3)
print("1 - 3 =", 1 - 3)
print("1 * 3 =", 1 * 3)
print("1 / 3 =", 1 / 3)
print("1 // 3 =", 1 // 3)  # Sin decimales
print("1 % 3 =", 1 % 3)
print("POTENCIA:", "2 ** 3 =", 2 ** 3)
