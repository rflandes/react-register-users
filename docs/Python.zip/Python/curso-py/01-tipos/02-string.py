nombre_curso = "ULTIMATE PYTHON"
descripcion_curso = """
Este es un texto
de prueba
se esta probando los saltos de linea
"""

print(nombre_curso)
print(descripcion_curso)

longitud_string = len(nombre_curso)
print(longitud_string)

print()
print("Array 'nombre_curso[5]':")
print(nombre_curso, ":", nombre_curso[5])

print()
print("Array substring 'nombre_curso[0:8]':")
print(nombre_curso, ":", nombre_curso[0:8])

print()
print("Array 'nombre_curso[9:]':")
print(nombre_curso, ":", nombre_curso[9:])

print()
print("Array 'nombre_curso[:8]':")
print(nombre_curso, ":", nombre_curso[:8])

print()
print("Array 'nombre_curso[:]':")
print(nombre_curso, ":", nombre_curso[:])
