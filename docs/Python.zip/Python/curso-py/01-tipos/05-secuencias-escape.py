print()
print("Secuencias de escape")

curso = "ULTIMATE PYTHON"

print()
print("COMILLA SIMPLE")
print('ULTIMATE "PYTHON"')

print()
print("BACKSLASH \\")
print("ULTIMATE \"PYTHON\"")

print()
print("Cometario #")
# Esto es un comentario de código


print()
print("SALTO DE LINEA \\n")
print("ULTIMATE \nPYTHON")
