print()
print("while")
print()

numero = 1
while numero < 100:
    print(numero)
    numero *= 2

print()
comando = ""
while comando.lower() != "salir":
    print("Escribe 'salir' para terminar")
    comando = input("$ ")
    print(comando)

print()
