print("IF - TERNARIO")
print()


edad = 15

# if edad > 17:
#     mensaje = "Es mayor"
# else:
#     mensaje = "Es menor"

mensaje = "Es mayor" if edad > 17 else "es menor"

print(mensaje)


print()
