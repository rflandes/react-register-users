print()
print("and | or | not")
print()

gas = True
encendido = True

if gas and encendido:
    print("Puedes avanzar")

if gas or encendido:
    print("Puedes avanzar")

if not gas or encendido:
    print("Puedes avanzar")

edad = 19
if not gas and (encendido or edad > 17):
    print("Puedes avanzar")

print()
