print()
print("CADENA DE COMPARADORES")
print()

edad = 25

if edad >= 15 and edad <= 65:
    print("Puede entrar a la piscina")

print()

if 15 <= edad <= 65:
    print("Puede entrar a la piscina")
