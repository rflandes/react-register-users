print("IF - ELSE")
print()

edad = 18

if edad > 54:
    print("Puede ver la pelicula con descuento")
elif edad > 17:
    print("Puede ver la pelicula")
else:
    print("No tienes edad para ver la pelicula")
    # La identacion es importante para establecer los bloques de inicio y fin
    print("Busca otra pelicula")

print()
print("Listo")
