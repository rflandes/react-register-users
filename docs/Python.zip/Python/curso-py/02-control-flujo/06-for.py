print()
print("FOR")
print()

for numero in range(5):
    print(numero + 1)

print()
for numero in range(5):
    print(numero, numero * "Hola Mundo ")

print()
buscar = 3
print("Buscar el numero", buscar)
for numero in range(5):
    print("Validando", numero)
    if numero == buscar:
        print("Numero encontrado", buscar)
        break

print()
buscar = 10
print("Buscar el numero", buscar)
for numero in range(5):
    print("Validando", numero)
    if numero == buscar:
        print("Numero encontrado", buscar)
        break
else:
    print("No encontré el numero", buscar)

print()
for char in "ULTIMATE PYTHON":
    print(char)

print()
