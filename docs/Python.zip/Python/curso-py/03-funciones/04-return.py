def suma(a, b):
    return a+b


print()
resultado = suma(1, 2)
print(resultado)
