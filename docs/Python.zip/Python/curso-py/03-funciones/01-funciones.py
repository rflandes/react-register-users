def hola(user, lastName="Toledo"):
    print("Hola Mundo")
    print("Ultimate Python")
    print(f"Bienvenido: {user} {lastName}")


print()
hola("Roberto")
print()
hola("Carlos", "Toledo")
print()
hola(lastName="Peña", user="Grethel")
print()
