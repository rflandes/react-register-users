def get_product(**datos):
    # **datos es un Dictionary
    print("Dentro de get_product:")
    print(datos)
    print()


def get_product2(**datos):
    # **datos es un Dictionary
    print("Dentro de get_product2:")
    print(datos["desc"])
    print()


print()
get_product(
    id="23",
    name="iPhone",
    desc="telefono celular")

get_product2(
    id="23",
    name="iPhone",
    desc="telefono celular")
print()
