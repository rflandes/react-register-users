def es_palindromo_rob(texto):
    texto_a_comparar = ""
    texto_lower_case = texto.lower().replace(" ", "")
    index = len(texto_lower_case)
    while True:
        texto_a_comparar += texto_lower_case[index - 1]
        index -= 1
        if index <= 0:
            break

    return texto_a_comparar == texto_lower_case


def no_space(texto):
    return texto.replace(" ", "")


def reverse(texto):
    reverse_text = ""

    for char in texto:
        reverse_text = char + reverse_text

    return reverse_text


def es_palindromo(texto):
    texto_lower_case = no_space(texto)
    texto_a_comparar = reverse(texto_lower_case)

    return texto_a_comparar.lower() == texto_lower_case.lower()


print()
print("Abba:", es_palindromo("Abba"))
print("Reconocer:", es_palindromo("Reconocer"))
print("Amo la paloma:", es_palindromo("Amo la paloma"))
print("Hola Mundo:", es_palindromo("Hola Mundo"))
print()
