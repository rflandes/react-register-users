"""XARGS"""


def suma(a, b):
    """Suma"""
    print("suma:", a+b)


print()
suma(2, 5)
print()


def suma2(*numeros):
    """Suma2"""
    resultado = 0
    for numero in numeros:
        resultado += numero
    print("suma2:", resultado)


print()
suma2(2, 5, 9, 11)
print()
