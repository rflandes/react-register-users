saludo = "Hola a todos"  # Variable global
"""
UTILIZAR VARIABLES GLOBALES EN PYTHON 
ES UNA MALA PRACTICA !!!
"""


def saludar():
    # print(saludo)
    saludo = "Hola Mundo"
    print(saludo)


def saludarUniverso():
    # print(saludo)
    saludo = "Hola Universo"
    print(saludo)


def saludarGlobal():
    global saludo
    saludo = "Hola Global modificado"


print()

saludar()
saludarUniverso()
print(saludo)

print()

saludarGlobal()
print(saludo)

print()
