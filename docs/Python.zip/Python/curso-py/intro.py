"""Introduccion a python."""

print("Hola Mundo")
print("El weta "  * 4)
