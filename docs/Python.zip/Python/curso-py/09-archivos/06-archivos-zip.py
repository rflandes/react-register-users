
from pathlib import Path
from zipfile import ZipFile

# escribir
# with ZipFile("09-archivos/comprimidos.zip", "w") as zip:
#     for path in Path().rglob("*.*"):
#         # print(path)
#         if str(path) != r"09-archivos\comprimidos.zip":
#             zip.write(path)


with ZipFile("09-archivos/comprimidos.zip") as zip:
    # print(zip.namelist())
    info = zip.getinfo("09-archivos/06-archivos-zip.py")
    print(
        info.file_size,
        info.compress_size
    )
    zip.extractall("09-archivos/descomprimidos")
