
from pathlib import Path
from time import ctime

archivo = Path("09-archivos/archivo-prueba.txt")

# archivo.exists()
# archivo.rename()
# archivo.unlink()
# print(archivo.stat())

print()

print("acceso", ctime(archivo.stat().st_atime))
print("creación", ctime(archivo.stat().st_ctime))
print("creación", ctime(archivo.stat().st_birthtime))
print("modificación", ctime(archivo.stat().st_mtime))

print()
print()
