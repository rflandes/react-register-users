
import json
from pathlib import Path

# escribir json
# productos = [
#     {"id": 1, "name": "Surfboard"},
#     {"id": 2, "name": "Bici"},
#     {"id": 3, "name": "Skate"},
# ]

# data = json.dumps(productos)
# # print(data)

# Path("09-archivos/productos.json").write_text(data)


#########################

# leer json
# data = Path("09-archivos/productos.json").read_text(encoding="utf-8")
# productos = json.loads(data)
# print(productos)


#########################

# modificar json
data = Path("09-archivos/productos.json").read_text(encoding="utf-8")
productos = json.loads(data)
productos[0]["name"] = "Chanchito feliz"

Path("09-archivos/productos.json").write_text(json.dumps(productos))
