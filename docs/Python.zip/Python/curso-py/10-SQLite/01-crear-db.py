

import sqlite3

con = sqlite3.connect("10-sqlite/app.db")
con.close()
